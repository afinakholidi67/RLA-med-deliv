# AEGIS-MED

Heterogeneous-fleet medical-logistics route optimizer (ALNS) with a FastAPI
backend, PostGIS persistence, optional OSRM routing and a single-page dashboard.

## Run

```
docker compose up --build
```

API: http://localhost:8000  | Dashboard: http://localhost:8000/  | Docs: /docs

Without OSRM data the engine uses the built-in synthetic traffic matrix.
