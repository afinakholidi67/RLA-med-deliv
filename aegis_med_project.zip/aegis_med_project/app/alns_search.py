from __future__ import annotations

import math
import random
from typing import Callable, Optional

from .alns_engine import (
    EngineConfig,
    ProblemInstance,
    Route,
    Solution,
    aggregate_objective,
    propagate,
)

_EPS = 1e-9

# A destruction operator returns (partially destroyed solution, removed ids);
# a repair operator returns a repaired solution.
DestroyOp = Callable[..., tuple[Solution, list[int]]]
RepairOp = Callable[..., Solution]


# Per-route cost helpers


def _weighted_route_cost(evaluation, config: EngineConfig) -> float:
    return (
        config.alpha * evaluation.reliability
        + config.beta * evaluation.time_value
        + config.gamma * evaluation.distance_cost
    )


def _best_in_route(
    solution: Solution, route_index: int, node_id: int, instance: ProblemInstance
) -> Optional[tuple[float, int, Route]]:
    cfg = instance.config
    route = solution.routes[route_index]
    evaluation = solution.evaluations[route_index]
    node = instance.nodes[node_id]
    vehicle = route.vehicle

    if cfg.enforce_agile_access and node.requires_agile and not vehicle.is_agile:
        return None
    if (
        cfg.enforce_capacity
        and evaluation.load_kg + node.demand_kg > vehicle.payload_capacity_kg + 1e-6
    ):
        return None

    old_cost = _weighted_route_cost(evaluation, cfg)
    visits = route.visits
    best: Optional[tuple[float, int, Route]] = None
    for position in range(len(visits) + 1):
        trial_visits = visits[:position] + (node_id,) + visits[position:]
        trial = route.with_visits(trial_visits)
        trial_eval = propagate(trial, instance)
        if not trial_eval.feasible:
            continue
        delta = _weighted_route_cost(trial_eval, cfg) - old_cost
        if best is None or delta < best[0]:
            best = (delta, position, trial)
    return best


def _removal_saving(
    solution: Solution, route_index: int, node_id: int, instance: ProblemInstance
) -> tuple[float, Route]:
    cfg = instance.config
    route = solution.routes[route_index]
    evaluation = solution.evaluations[route_index]
    reduced = route.with_visits(tuple(n for n in route.visits if n != node_id))
    reduced_eval = propagate(reduced, instance)
    saving = _weighted_route_cost(evaluation, cfg) - _weighted_route_cost(
        reduced_eval, cfg
    )
    return saving, reduced


# Repair (shared cached engine; greedy + regret-k are thin wrappers)


def _route_options(
    solution: Solution, node_id: int, instance: ProblemInstance
) -> dict[int, tuple[float, int, Route]]:
    options: dict[int, tuple[float, int, Route]] = {}
    for r_idx in range(len(solution.routes)):
        best = _best_in_route(solution, r_idx, node_id, instance)
        if best is not None:
            options[r_idx] = best
    return options


def _repair(
    solution: Solution,
    candidates: list[int],
    instance: ProblemInstance,
    *,
    strategy: str,
    k: int = 1,
) -> Solution:
    cfg = instance.config
    big_m = cfg.unassigned_penalty
    unassigned_set = set(solution.unassigned)
    pending = [n for n in candidates if n in unassigned_set]

    work = solution
    cache: dict[int, dict[int, tuple[float, int, Route]]] = {
        n: _route_options(work, n, instance) for n in pending
    }
    inserted: set[int] = set()

    while pending:
        # rank current feasible insertions for each node
        ranked: dict[int, list[tuple[int, tuple[float, int, Route]]]] = {}
        stuck: list[int] = []
        for n in pending:
            options = cache[n]
            if not options:
                stuck.append(n)  # if feasible slot now it stays unassigned
                continue
            ranked[n] = sorted(options.items(), key=lambda kv: kv[1][0])
        for n in stuck:
            pending.remove(n)
        if not ranked:
            break

        if strategy == "greedy":
            node = min(ranked, key=lambda n: ranked[n][0][1][0])
        else:  # regretk maximize the gap to the next best alternatives
            def regret_value(n: int) -> float:
                opts = ranked[n]
                best = opts[0][1][0]
                total = 0.0
                for i in range(1, k):
                    total += (opts[i][1][0] - best) if i < len(opts) else big_m
                return total

            node = max(ranked, key=lambda n: (regret_value(n), -ranked[n][0][1][0]))

        r_idx, (_, _, new_route) = ranked[node][0]
        work = work.replace_route(r_idx, new_route, instance)
        inserted.add(node)
        pending.remove(node)
        cache.pop(node, None)

        # recompute only the changed column
        for n in pending:
            refreshed = _best_in_route(work, r_idx, n, instance)
            if refreshed is None:
                cache[n].pop(r_idx, None)
            else:
                cache[n][r_idx] = refreshed

    #assemble directly from cached per-route evaluations (no full rebuild)
    final_unassigned = tuple(n for n in work.unassigned if n not in inserted)
    objective = aggregate_objective(work.evaluations, len(final_unassigned), cfg)
    feasible = not final_unassigned and all(e.feasible for e in work.evaluations)
    return Solution(
        routes=work.routes,
        unassigned=final_unassigned,
        evaluations=work.evaluations,
        objective=objective,
        feasible=feasible,
    )


def greedy_insertion(
    solution: Solution,
    candidates: list[int],
    instance: ProblemInstance,
    *,
    rng: Optional[random.Random] = None,
) -> Solution:
    return _repair(solution, candidates, instance, strategy="greedy", k=1)


def regret_k_insertion(
    solution: Solution,
    candidates: list[int],
    instance: ProblemInstance,
    *,
    rng: Optional[random.Random] = None,
) -> Solution:
    k = max(2, instance.config.regret_k)
    return _repair(solution, candidates, instance, strategy="regret", k=k)


def shaw_removal(
    solution: Solution,
    q: int,
    instance: ProblemInstance,
    *,
    rng: Optional[random.Random] = None,
    determinism: float = 5.0,
) -> tuple[Solution, list[int]]:
    cfg = instance.config
    rng = rng or random.Random(cfg.random_seed)
    matrix = instance.matrix

    assigned = [n for route in solution.routes for n in route.visits]
    if not assigned:
        return solution, []
    q = min(q, len(assigned))

    arrival: dict[int, float] = {}
    for route, evaluation in zip(solution.routes, solution.evaluations):
        for node_id, arr in zip(route.visits, evaluation.arrivals):
            arrival[node_id] = arr

    dist_scale = float(matrix.distance_km.max()) or 1.0
    time_scale = (max(arrival.values()) - min(arrival.values())) or 1.0
    demand_scale = max(
        (instance.nodes[n].demand_kg for n in assigned), default=1.0
    ) or 1.0

    def relatedness(i: int, j: int) -> float:
        ni, nj = instance.nodes[i], instance.nodes[j]
        d = matrix.distance(ni.key, nj.key) / dist_scale
        t = abs(arrival[i] - arrival[j]) / time_scale
        w = abs(ni.demand_kg - nj.demand_kg) / demand_scale
        return (
            cfg.shaw_weight_distance * d
            + cfg.shaw_weight_time * t
            + cfg.shaw_weight_demand * w
        )

    removed = [rng.choice(assigned)]
    removed_set = set(removed)
    while len(removed) < q:
        reference = rng.choice(removed)
        pool = [n for n in assigned if n not in removed_set]
        if not pool:
            break
        pool.sort(key=lambda n: relatedness(reference, n))
        index = int(len(pool) * (rng.random() ** determinism))
        chosen = pool[min(index, len(pool) - 1)]
        removed.append(chosen)
        removed_set.add(chosen)

    new_routes = tuple(
        route.with_visits(tuple(n for n in route.visits if n not in removed_set))
        for route in solution.routes
    )
    new_unassigned = tuple(solution.unassigned) + tuple(removed)
    return Solution.build(new_routes, new_unassigned, instance), list(removed)


def worst_cost_removal(
    solution: Solution,
    q: int,
    instance: ProblemInstance,
    *,
    rng: Optional[random.Random] = None,
    determinism: float = 3.0,
) -> tuple[Solution, list[int]]:
    cfg = instance.config
    rng = rng or random.Random(cfg.random_seed)

    node_route = {
        n: r_idx for r_idx, route in enumerate(solution.routes) for n in route.visits
    }
    if not node_route:
        return solution, []
    q = min(q, len(node_route))

    work = solution
    saving_cache: dict[int, tuple[float, int, Route]] = {}
    for node_id, r_idx in node_route.items():
        saving, reduced = _removal_saving(work, r_idx, node_id, instance)
        saving_cache[node_id] = (saving, r_idx, reduced)

    removed: list[int] = []
    for _ in range(q):
        if not saving_cache:
            break
        ranked = sorted(saving_cache.items(), key=lambda kv: -kv[1][0])
        index = int(len(ranked) * (rng.random() ** determinism))
        node_id, (_, r_idx, reduced) = ranked[min(index, len(ranked) - 1)]

        work = work.replace_route(r_idx, reduced, instance)
        removed.append(node_id)
        saving_cache.pop(node_id, None)
        del node_route[node_id]

        for other, other_route in node_route.items():
            if other_route == r_idx:
                saving, reduced_other = _removal_saving(work, r_idx, other, instance)
                saving_cache[other] = (saving, r_idx, reduced_other)

    final_unassigned = tuple(work.unassigned) + tuple(removed)
    objective = aggregate_objective(work.evaluations, len(final_unassigned), cfg)
    feasible = not final_unassigned and all(e.feasible for e in work.evaluations)
    new_solution = Solution(
        routes=work.routes,
        unassigned=final_unassigned,
        evaluations=work.evaluations,
        objective=objective,
        feasible=feasible,
    )
    return new_solution, removed


#urgentanchor greedy construction



def generate_initial_solution(instance: ProblemInstance) -> Solution:
    solution = Solution.empty(instance)
    urgent = list(instance.urgent_ids)
    urgent_set = set(urgent)
    standard = [n for n in instance.node_ids if n not in urgent_set]

    if urgent:
        solution = greedy_insertion(solution, urgent, instance)
    if standard:
        solution = greedy_insertion(solution, standard, instance)
    return solution


#adaptive simulated-annealing master loop


def _roulette(weights: list[float], rng: random.Random) -> int:
    total = sum(weights)
    if total <= 0.0:
        return rng.randrange(len(weights))
    threshold = rng.random() * total
    acc = 0.0
    for i, w in enumerate(weights):
        acc += w
        if threshold <= acc:
            return i
    return len(weights) - 1


def alns_optimize(
    instance: ProblemInstance,
    *,
    verbose: bool = False,
    on_iteration: Optional[Callable[[int, Solution, Solution, float], None]] = None,
) -> Solution:
    cfg = instance.config
    rng = random.Random(cfg.random_seed)

    current = best = generate_initial_solution(instance)

    temperature = cfg.sa_start_temperature
    if temperature <= 0.0:
        seed_cost = abs(best.cost) or 1.0
        # exp(-(0.05 * Z0) / T) = 0.5  ->  T = 0.05 * Z0 / ln(2)
        temperature = (0.05 * seed_cost) / math.log(2.0)

    destroy_ops: list[tuple[str, DestroyOp]] = [
        ("shaw", shaw_removal),
        ("worst", worst_cost_removal),
    ]
    repair_ops: list[tuple[str, RepairOp]] = [
        ("greedy", greedy_insertion),
        ("regret", regret_k_insertion),
    ]
    d_weight = [1.0] * len(destroy_ops)
    r_weight = [1.0] * len(repair_ops)
    d_score = [0.0] * len(destroy_ops)
    r_score = [0.0] * len(repair_ops)
    d_used = [0] * len(destroy_ops)
    r_used = [0] * len(repair_ops)

    n_nodes = len(instance.nodes)
    q_min = max(1, int(cfg.min_removal_fraction * n_nodes))
    q_max = max(q_min, int(cfg.max_removal_fraction * n_nodes))

    for iteration in range(1, cfg.max_iterations + 1):
        d_idx = _roulette(d_weight, rng)
        r_idx = _roulette(r_weight, rng)

        q = rng.randint(q_min, q_max)
        q = max(1, min(q, current.assigned_count))

        destroyed, removed = destroy_ops[d_idx][1](current, q, instance, rng=rng)
        candidate = repair_ops[r_idx][1](destroyed, removed, instance, rng=rng)

        delta = candidate.cost - current.cost
        reward = 0.0
        accepted = False
        if candidate.cost < best.cost - _EPS:
            best = candidate
            accepted = True
            reward = cfg.score_new_best
        elif delta < -_EPS:
            accepted = True
            reward = cfg.score_improved
        else:
            probability = (
                math.exp(-delta / temperature) if temperature > 1e-12 else 0.0
            )
            if rng.random() < probability:
                accepted = True
                reward = cfg.score_accepted
        if accepted:
            current = candidate

        d_score[d_idx] += reward
        r_score[r_idx] += reward
        d_used[d_idx] += 1
        r_used[r_idx] += 1

        temperature = max(temperature * cfg.sa_cooling_rate, cfg.sa_min_temperature)

        if iteration % cfg.segment_size == 0:
            for i in range(len(d_weight)):
                if d_used[i] > 0:
                    d_weight[i] = (
                        d_weight[i] * (1.0 - cfg.reaction_factor)
                        + cfg.reaction_factor * (d_score[i] / d_used[i])
                    )
                d_score[i] = 0.0
                d_used[i] = 0
            for i in range(len(r_weight)):
                if r_used[i] > 0:
                    r_weight[i] = (
                        r_weight[i] * (1.0 - cfg.reaction_factor)
                        + cfg.reaction_factor * (r_score[i] / r_used[i])
                    )
                r_score[i] = 0.0
                r_used[i] = 0
            if verbose:
                print(
                    f"iter {iteration:>6}  best={best.cost:>14,.1f}  "
                    f"cur={current.cost:>14,.1f}  T={temperature:>10.3g}  "
                    f"dW={[round(w, 2) for w in d_weight]}  "
                    f"rW={[round(w, 2) for w in r_weight]}"
                )

        if on_iteration is not None:
            on_iteration(iteration, current, best, temperature)

    return best


__all__ = [
    "generate_initial_solution",
    "shaw_removal",
    "worst_cost_removal",
    "greedy_insertion",
    "regret_k_insertion",
    "alns_optimize",
]
