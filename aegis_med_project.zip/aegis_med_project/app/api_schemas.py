from __future__ import annotations

import datetime as dt
from typing import Annotated, Optional

from pydantic import BaseModel, ConfigDict, Field, field_validator

from .jobs_models import JobStatus

_Frac = Annotated[float, Field(gt=0.0, le=1.0)]
_Pos = Annotated[float, Field(gt=0.0)]
_NonNeg = Annotated[float, Field(ge=0.0)]


class EngineConfigOverrides(BaseModel):

    model_config = ConfigDict(extra="forbid")

    #objective weights
    alpha: Optional[_NonNeg] = None
    beta: Optional[_NonNeg] = None
    gamma: Optional[_NonNeg] = None

    #Penalties!!
    unassigned_penalty: Optional[_Pos] = None
    window_violation_weight: Optional[_NonNeg] = None
    default_stagnation_minutes: Optional[_NonNeg] = None

    #feasibility behaviour
    shift_counts_waiting: Optional[bool] = None

    #search controls
    random_seed: Optional[int] = None
    max_iterations: Optional[Annotated[int, Field(ge=1, le=2_000_000)]] = None
    segment_size: Optional[Annotated[int, Field(ge=1)]] = None
    reaction_factor: Optional[_Frac] = None
    sa_start_temperature: Optional[_NonNeg] = None
    sa_cooling_rate: Optional[Annotated[float, Field(gt=0.0, lt=1.0)]] = None
    sa_min_temperature: Optional[_Pos] = None
    regret_k: Optional[Annotated[int, Field(ge=2, le=10)]] = None
    min_removal_fraction: Optional[_Frac] = None
    max_removal_fraction: Optional[_Frac] = None
    shaw_weight_distance: Optional[_NonNeg] = None
    shaw_weight_time: Optional[_NonNeg] = None
    shaw_weight_demand: Optional[_NonNeg] = None

    def to_overrides(self) -> dict[str, object]:
        return self.model_dump(exclude_none=True)


class EntitySelectionRequest(BaseModel):

    depot_id: int = Field(gt=0)
    node_ids: list[int] = Field(min_length=1)
    vehicle_ids: list[int] = Field(min_length=1)

    @field_validator("node_ids", "vehicle_ids")
    @classmethod
    def _positive_unique(cls, value: list[int]) -> list[int]:
        if any(v <= 0 for v in value):
            raise ValueError("ids must be positive integers")
        # Preserve order while de-duplicating.
        seen: set[int] = set()
        return [v for v in value if not (v in seen or seen.add(v))]


class OptimizeRequest(EntitySelectionRequest):

    config: EngineConfigOverrides = Field(default_factory=EngineConfigOverrides)


class PrecomputeRequest(EntitySelectionRequest):
    pass


class PrecomputeResponse(BaseModel):

    status: str = "accepted"
    depot_id: int
    node_count: int
    vehicle_count: int
    detail: str = "matrix precompute scheduled"


class JobSubmitResponse(BaseModel):

    job_id: str
    status: JobStatus
    submitted_at: dt.datetime


class ObjectiveBreakdownOut(BaseModel):

    reliability: float
    time: float
    distance_cost: float
    unassigned_count: int
    weighted_reliability: float
    weighted_time: float
    weighted_distance: float
    unassigned_penalty: float
    total: float


class RouteAssignmentOut(BaseModel):

    model_config = ConfigDict(from_attributes=True)

    sequence_index: int
    vehicle_id: int
    vehicle_label: str
    visits: list[int]
    load_kg: float
    distance_km: float
    shift_minutes: float
    max_seal_minutes: float
    time_value: float
    distance_cost: float
    reliability: float
    feasible: bool


class JobStatusResponse(BaseModel):

    job_id: str
    status: JobStatus
    submitted_at: dt.datetime
    started_at: Optional[dt.datetime] = None
    finished_at: Optional[dt.datetime] = None
    error: Optional[str] = None

    #present only when COMPLETED
    feasible: Optional[bool] = None
    total_cost: Optional[float] = None
    objective: Optional[ObjectiveBreakdownOut] = None
    unassigned: list[int] = Field(default_factory=list)
    routes: list[RouteAssignmentOut] = Field(default_factory=list)


__all__ = [
    "EngineConfigOverrides",
    "EntitySelectionRequest",
    "OptimizeRequest",
    "PrecomputeRequest",
    "PrecomputeResponse",
    "JobSubmitResponse",
    "ObjectiveBreakdownOut",
    "RouteAssignmentOut",
    "JobStatusResponse",
]
