"""
AEGIS-MED :: Île-de-France reference dataset.

* 1 main depot (Rungis logistics hub, t0 = 08:00 dispatch).
* 25 vehicles  — 18 agile small units (11 electric + 7 diesel) and 7 large
  diesel box trucks, with per-class payload / range taken from the interview.
* 183 delivery nodes — 145 pharmacies + 38 clinics, scattered with small
  jitter around real Île-de-France commune / arrondissement centroids.
* ~65% of nodes carry a delivery time window (pharmacies 08:30–11:00, clinics
  either 09:00–12:00 or the afternoon 14:00–16:00 slot).
* ~20% of nodes are URGENT (vaccines / temperature-sensitive / hospital), with
  a tight "before-noon" window; urgent demand is weighted toward clinics.
* Central-Paris pharmacies are flagged ``requires_agile`` (dense city centre,
  short multi-stop routes — the small fleet's home turf).

Every record is validated through the project's own Pydantic ``*Create``
schemas before it touches the database, so a malformed seed fails loudly and
locally rather than as a constraint violation deep in the ORM flush.

Run it standalone (DB must be reachable, see database.py / docker-compose):

    python -m app.seed_data            # insert if empty
    python -m app.seed_data --reset    # wipe delivery data + reseed
"""
from __future__ import annotations

import argparse
import random
from dataclasses import dataclass
from typing import Iterable

from sqlalchemy import delete, func, select
from sqlalchemy.orm import Session

from .constants import (
    DeliveryPriority,
    NodeType,
    PowertrainType,
    VehicleClass,
)
from .database import SessionLocal, create_all
from .models import DeliveryNode, Depot, Vehicle
from .schemas import DeliveryNodeCreate, DepotCreate, VehicleCreate

# Reproducible spatial scatter.
SEED = 20240601

#min day helpers.
def _hm(hour: int, minute: int = 0) -> int:
    return hour * 60 + minute


#Interview windows (minutes from local midnight).
TW_PHARMACY = (_hm(8, 30), _hm(11, 0))# 510–660
TW_CLINIC_AM = (_hm(9, 0), _hm(12, 0))# 540–720
TW_CLINIC_PM = (_hm(14, 0), _hm(16, 0))# 840–960
TW_URGENT_BEFORE_NOON = (_hm(8, 30), _hm(12, 0))# 510–720

#real Île-de-France anchors. Nodes are jittered around these so the
# dataset is synthetic but stays on land and inside the region.

DEPOT_RUNGIS = ("Rungis Main Depot", 48.7490, 2.3510)

#(name, lat, lon, weight) — weight steers how many nodes cluster here.
ANCHORS: list[tuple[str, float, float, int]] = [
    #Paris intra-muros (dense — high weight)
    ("Paris 1er", 48.8607, 2.3358, 5),
    ("Paris 2e", 48.8680, 2.3414, 4),
    ("Paris 3e", 48.8637, 2.3615, 4),
    ("Paris 4e", 48.8557, 2.3582, 4),
    ("Paris 5e", 48.8448, 2.3471, 5),
    ("Paris 6e", 48.8496, 2.3329, 4),
    ("Paris 7e", 48.8566, 2.3120, 4),
    ("Paris 8e", 48.8721, 2.3120, 4),
    ("Paris 9e", 48.8769, 2.3390, 5),
    ("Paris 10e", 48.8760, 2.3590, 5),
    ("Paris 11e", 48.8580, 2.3793, 6),
    ("Paris 12e", 48.8403, 2.3950, 5),
    ("Paris 13e", 48.8322, 2.3561, 6),
    ("Paris 14e", 48.8331, 2.3264, 5),
    ("Paris 15e", 48.8417, 2.2998, 7),
    ("Paris 16e", 48.8635, 2.2769, 5),
    ("Paris 17e", 48.8872, 2.3070, 6),
    ("Paris 18e", 48.8927, 2.3444, 6),
    ("Paris 19e", 48.8847, 2.3822, 5),
    ("Paris 20e", 48.8649, 2.3984, 5),
    # Inner ring (92 / 93 / 94)
    ("Boulogne-Billancourt", 48.8333, 2.2400, 4),
    ("Nanterre", 48.8924, 2.2065, 3),
    ("Saint-Denis", 48.9362, 2.3574, 4),
    ("Montreuil", 48.8638, 2.4485, 3),
    ("Créteil", 48.7900, 2.4556, 3),
    ("Vincennes", 48.8478, 2.4370, 2),
    ("Issy-les-Moulineaux", 48.8246, 2.2730, 3),
    ("Levallois-Perret", 48.8939, 2.2873, 3),
    ("Courbevoie", 48.8970, 2.2566, 2),
    ("Aubervilliers", 48.9146, 2.3835, 2),
    ("Ivry-sur-Seine", 48.8132, 2.3880, 2),
    ("Vitry-sur-Seine", 48.7872, 2.3927, 2),
    ("Clichy", 48.9044, 2.3064, 2),
    ("Asnières-sur-Seine", 48.9118, 2.2853, 2),
    # Outer ring (77 / 78 / 91 / 95) — sparse
    ("Versailles", 48.8014, 2.1301, 2),
    ("Saint-Germain-en-Laye", 48.8990, 2.0938, 1),
    ("Cergy", 49.0361, 2.0631, 1),
    ("Évry", 48.6296, 2.4416, 1),
    ("Pontoise", 49.0510, 2.1015, 1),
    ("Meaux", 48.9602, 2.8782, 1),
]

PARIS_INTRA = {a[0] for a in ANCHORS if a[0].startswith("Paris ")}

TARGET_PHARMACIES = 145
TARGET_CLINICS = 38
URGENT_SHARE = 0.20
CONSTRAINED_SHARE = 0.65


@dataclass(frozen=True)
class _NodeSpec:
    external_ref: str
    name: str
    node_type: NodeType
    latitude: float
    longitude: float
    demand_kg: float
    service_time_minutes: float
    priority: DeliveryPriority
    is_time_constrained: bool
    tw_open_minute: int | None
    tw_close_minute: int | None
    requires_agile: bool


def _jitter(rng: random.Random, lat: float, lon: float) -> tuple[float, float]:
    # aprox more or less 350 m so points spread around the anchor without leaving the commune
    return (
        round(lat + rng.uniform(-0.004, 0.004), 6),
        round(lon + rng.uniform(-0.005, 0.005), 6),
    )


def _weighted_anchor_pool() -> list[tuple[str, float, float]]:
    pool: list[tuple[str, float, float]] = []
    for name, lat, lon, weight in ANCHORS:
        pool.extend([(name, lat, lon)] * weight)
    return pool


def build_vehicle_specs() -> list[dict]:
    """25 vehicles: 11 small electric + 7 small diesel + 7 large diesel."""
    rng = random.Random(SEED)
    specs: list[dict] = []

    for i in range(1, 12):# 11 electric agile vans
        specs.append(
            dict(
                label=f"SM-E-{i:02d}",
                vehicle_class=VehicleClass.SMALL,
                powertrain=PowertrainType.ELECTRIC,
                payload_capacity_kg=round(rng.uniform(440, 560), 0),
                range_km=round(rng.uniform(170, 200), 0),# electric 160–200/day
                cost_per_km=0.06,
                fixed_dispatch_cost=8.0,
                depot_id=1,
            )
        )
    for i in range(1, 8):# 7 diesel agile vans (heavier payload longer range)
        specs.append(
            dict(
                label=f"SM-D-{i:02d}",
                vehicle_class=VehicleClass.SMALL,
                powertrain=PowertrainType.DIESEL,
                payload_capacity_kg=round(rng.uniform(580, 690), 0),# up to ~700
                range_km=round(rng.uniform(340, 360), 0),# diesel ~350/day
                cost_per_km=0.18,
                fixed_dispatch_cost=12.0,
                depot_id=1,
            )
        )
    for i in range(1, 8):#7 large diesel box trucks
        specs.append(
            dict(
                label=f"LG-D-{i:02d}",
                vehicle_class=VehicleClass.LARGE,
                powertrain=PowertrainType.DIESEL,
                payload_capacity_kg=round(rng.uniform(2800, 3900), 0),
                range_km=round(rng.uniform(650, 800), 0),
                cost_per_km=0.42,
                fixed_dispatch_cost=40.0,
                depot_id=1,
            )
        )
    return specs


def build_node_specs() -> list[_NodeSpec]:
    rng = random.Random(SEED)
    pool = _weighted_anchor_pool()

    #Decide urgent constrained membership up front for stable proportions
    total = TARGET_PHARMACIES + TARGET_CLINICS
    n_urgent = round(total * URGENT_SHARE)
    n_constrained = round(total * CONSTRAINED_SHARE)

    nodes: list[_NodeSpec] = []
    idx = list(range(total))
    rng.shuffle(idx)
    urgent_set = set(idx[:n_urgent])
    #Constrained set drawn so urgent nodes are preferentially time constrained
    constrained_order = idx[:n_urgent] + idx[n_urgent:]
    constrained_set = set(constrained_order[:n_constrained])

    def make(seq: int, kind: NodeType) -> _NodeSpec:
        anchor_name, alat, alon = rng.choice(pool)
        lat, lon = _jitter(rng, alat, alon)
        urgent = seq in urgent_set
        constrained = seq in constrained_set or urgent
        priority = DeliveryPriority.URGENT if urgent else DeliveryPriority.STANDARD

        if kind == NodeType.PHARMACY:
            ref = f"PH-{seq:04d}"
            name = f"Pharmacie {anchor_name} #{seq:03d}"
            demand = round(rng.uniform(10, 80), 1)
            service = round(rng.uniform(8, 12), 1)
            requires_agile = anchor_name in PARIS_INTRA and rng.random() < 0.55
            window = TW_PHARMACY
        else:
            ref = f"CL-{seq:04d}"
            name = f"Centre médical {anchor_name} #{seq:03d}"
            demand = round(rng.uniform(60, 380), 1)
            service = round(rng.uniform(12, 22), 1)
            requires_agile = False
            window = TW_CLINIC_AM if rng.random() < 0.6 else TW_CLINIC_PM

        if urgent:
            window = TW_URGENT_BEFORE_NOON# critical supplies, before noon

        tw_open, tw_close = window if constrained else (None, None)
        return _NodeSpec(
            external_ref=ref,
            name=name,
            node_type=kind,
            latitude=lat,
            longitude=lon,
            demand_kg=demand,
            service_time_minutes=service,
            priority=priority,
            is_time_constrained=constrained,
            tw_open_minute=tw_open,
            tw_close_minute=tw_close,
            requires_agile=requires_agile,
        )

    seq = 1
    for _ in range(TARGET_PHARMACIES):
        nodes.append(make(seq - 1, NodeType.PHARMACY))
        seq += 1
    for _ in range(TARGET_CLINICS):
        nodes.append(make(seq - 1, NodeType.CLINIC))
        seq += 1
    return nodes



def validate_dataset() -> tuple[DepotCreate, list[VehicleCreate], list[DeliveryNodeCreate]]:
    """Build and validate every record through the project's Create schemas.

    Pure (no DB). Raises pydantic.ValidationError on the first bad record.
    """
    depot = DepotCreate(
        name=DEPOT_RUNGIS[0],
        latitude=DEPOT_RUNGIS[1],
        longitude=DEPOT_RUNGIS[2],
    )
    vehicles = [VehicleCreate(**v) for v in build_vehicle_specs()]
    nodes = [
        DeliveryNodeCreate(
            external_ref=n.external_ref,
            name=n.name,
            node_type=n.node_type,
            latitude=n.latitude,
            longitude=n.longitude,
            demand_kg=n.demand_kg,
            service_time_minutes=n.service_time_minutes,
            priority=n.priority,
            is_time_constrained=n.is_time_constrained,
            tw_open_minute=n.tw_open_minute,
            tw_close_minute=n.tw_close_minute,
            requires_agile=n.requires_agile,
        )
        for n in build_node_specs()
    ]
    return depot, vehicles, nodes


def seed(session: Session, *, reset: bool = False) -> dict[str, int]:
    depot_dto, vehicle_dtos, node_dtos = validate_dataset()

    if reset:
        session.execute(delete(Vehicle))
        session.execute(delete(DeliveryNode))
        session.execute(delete(Depot))
        session.flush()

    existing = session.scalar(select(func.count()).select_from(Depot))
    if existing and not reset:
        return {"skipped": existing, "depots": 0, "vehicles": 0, "nodes": 0}

    depot = Depot(**depot_dto.model_dump())
    session.add(depot)
    session.flush()# assign depot.id

    for dto in vehicle_dtos:
        data = dto.model_dump()
        data["depot_id"] = depot.id
        session.add(Vehicle(**data))

    session.add_all(DeliveryNode(**dto.model_dump()) for dto in node_dtos)
    session.commit()
    return {
        "depots": 1,
        "vehicles": len(vehicle_dtos),
        "nodes": len(node_dtos),
        "skipped": 0,
    }


def main(argv: Iterable[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description="Seed AEGIS-MED Île-de-France data.")
    parser.add_argument(
        "--reset", action="store_true", help="wipe depots/vehicles/nodes first"
    )
    args = parser.parse_args(list(argv) if argv is not None else None)

    create_all()
    with SessionLocal() as session:
        result = seed(session, reset=args.reset)
    print("seed result:", result)


if __name__ == "__main__":
    main()
