from __future__ import annotations

import datetime as dt
from typing import Optional

from geoalchemy2 import Geography
from geoalchemy2.elements import WKTElement
from sqlalchemy import (
    Boolean,
    CheckConstraint,
    Enum as SAEnum,
    Float,
    ForeignKey,
    Index,
    Integer,
    String,
    UniqueConstraint,
    event,
    func,
)
from sqlalchemy.orm import (
    DeclarativeBase,
    Mapped,
    mapped_column,
    relationship,
    validates,
)

from .constants import (
    DEFAULT_DISPATCH_MINUTES,
    DEFAULT_SERVICE_MINUTES,
    LOCATION_KEY_DEPOT,
    LOCATION_KEY_NODE,
    SRID_WGS84,
    DeliveryPriority,
    NodeType,
    PowertrainType,
    VehicleClass,
    location_key,
)

_POINT = Geography(geometry_type="POINT", srid=SRID_WGS84, spatial_index=False)


class Base(DeclarativeBase):
    pass


class TimestampMixin:

    created_at: Mapped[dt.datetime] = mapped_column(
        server_default=func.now(), nullable=False
    )
    updated_at: Mapped[dt.datetime] = mapped_column(
        server_default=func.now(), onupdate=func.now(), nullable=False
    )


class GeoLocatedMixin:

    latitude: Mapped[float] = mapped_column(Float, nullable=False)
    longitude: Mapped[float] = mapped_column(Float, nullable=False)
    #populated automatically from lat/lon by the geom-sync event listeners.
    geom: Mapped[Optional[object]] = mapped_column(_POINT, nullable=True)

    @validates("latitude")
    def _validate_latitude(self, _key: str, value: float) -> float:
        if value is None or not (-90.0 <= value <= 90.0):
            raise ValueError(f"latitude out of range [-90, 90]: {value!r}")
        return value

    @validates("longitude")
    def _validate_longitude(self, _key: str, value: float) -> float:
        if value is None or not (-180.0 <= value <= 180.0):
            raise ValueError(f"longitude out of range [-180, 180]: {value!r}")
        return value

# Depot


class Depot(GeoLocatedMixin, TimestampMixin, Base):

    __tablename__ = "depots"
    __table_args__ = (
        CheckConstraint("latitude BETWEEN -90 AND 90", name="ck_depot_lat"),
        CheckConstraint("longitude BETWEEN -180 AND 180", name="ck_depot_lon"),
        CheckConstraint(
            "default_dispatch_minute BETWEEN 0 AND 1440",
            name="ck_depot_dispatch_minute",
        ),
        Index("ix_depots_geom", "geom", postgresql_using="gist"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(120), nullable=False)
    default_dispatch_minute: Mapped[int] = mapped_column(
        Integer, nullable=False, default=DEFAULT_DISPATCH_MINUTES
    )

    vehicles: Mapped[list["Vehicle"]] = relationship(
        back_populates="depot", cascade="all, delete-orphan"
    )

    @property
    def location_key(self) -> str:
        return location_key(LOCATION_KEY_DEPOT, self.id)

    def __repr__(self) -> str:  # pragma: no cover - debug aid
        return f"<Depot id={self.id} name={self.name!r}>"


#vec

class Vehicle(TimestampMixin, Base):

    __tablename__ = "vehicles"
    __table_args__ = (
        UniqueConstraint("label", name="uq_vehicle_label"),
        CheckConstraint("payload_capacity_kg > 0", name="ck_vehicle_payload_pos"),
        CheckConstraint("range_km > 0", name="ck_vehicle_range_pos"),
        CheckConstraint("cost_per_km >= 0", name="ck_vehicle_cost_nonneg"),
        CheckConstraint(
            "fixed_dispatch_cost >= 0", name="ck_vehicle_fixed_cost_nonneg"
        ),
        Index("ix_vehicles_class_active", "vehicle_class", "active"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    label: Mapped[str] = mapped_column(String(64), nullable=False)
    vehicle_class: Mapped[VehicleClass] = mapped_column(
        SAEnum(VehicleClass, name="vehicle_class", native_enum=False),
        nullable=False,
    )
    powertrain: Mapped[PowertrainType] = mapped_column(
        SAEnum(PowertrainType, name="powertrain_type", native_enum=False),
        nullable=False,
    )
    payload_capacity_kg: Mapped[float] = mapped_column(Float, nullable=False)
    range_km: Mapped[float] = mapped_column(Float, nullable=False)
    #operating cost per km (fuel for diesel energy for electric) feeds gamma*_*
    cost_per_km: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    #optional fixed cost incurred when the vehicle is used at all
    fixed_dispatch_cost: Mapped[float] = mapped_column(
        Float, nullable=False, default=0.0
    )
    #optional pervehicle speed override (km/h)if None than network default
    avg_speed_kmh: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)

    depot_id: Mapped[int] = mapped_column(
        ForeignKey("depots.id", ondelete="CASCADE"), nullable=False
    )
    depot: Mapped["Depot"] = relationship(back_populates="vehicles")

    @property
    def is_agile(self) -> bool:
        return self.vehicle_class == VehicleClass.SMALL

    def __repr__(self) -> str:  # pragma: no cover - debug aid
        return (
            f"<Vehicle id={self.id} label={self.label!r} "
            f"class={self.vehicle_class.value} cap={self.payload_capacity_kg}kg>"
        )


# Delivery node


class DeliveryNode(GeoLocatedMixin, TimestampMixin, Base):

    __tablename__ = "delivery_nodes"
    __table_args__ = (
        UniqueConstraint("external_ref", name="uq_node_external_ref"),
        CheckConstraint("latitude BETWEEN -90 AND 90", name="ck_node_lat"),
        CheckConstraint("longitude BETWEEN -180 AND 180", name="ck_node_lon"),
        CheckConstraint("demand_kg >= 0", name="ck_node_demand_nonneg"),
        CheckConstraint(
            "service_time_minutes >= 0", name="ck_node_service_nonneg"
        ),
        CheckConstraint(
            "tw_open_minute IS NULL OR (tw_open_minute BETWEEN 0 AND 1440)",
            name="ck_node_tw_open_range",
        ),
        CheckConstraint(
            "tw_close_minute IS NULL OR (tw_close_minute BETWEEN 0 AND 1440)",
            name="ck_node_tw_close_range",
        ),
        CheckConstraint(
            "tw_open_minute IS NULL OR tw_close_minute IS NULL "
            "OR tw_open_minute < tw_close_minute",
            name="ck_node_tw_order",
        ),
        Index("ix_nodes_geom", "geom", postgresql_using="gist"),
        Index("ix_nodes_priority", "priority"),
        Index("ix_nodes_window", "tw_open_minute", "tw_close_minute"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    external_ref: Mapped[str] = mapped_column(String(64), nullable=False)
    name: Mapped[str] = mapped_column(String(160), nullable=False)
    node_type: Mapped[NodeType] = mapped_column(
        SAEnum(NodeType, name="node_type", native_enum=False), nullable=False
    )

    demand_kg: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    service_time_minutes: Mapped[float] = mapped_column(
        Float, nullable=False, default=DEFAULT_SERVICE_MINUTES
    )

    priority: Mapped[DeliveryPriority] = mapped_column(
        SAEnum(DeliveryPriority, name="delivery_priority", native_enum=False),
        nullable=False,
        default=DeliveryPriority.STANDARD,
    )
    is_time_constrained: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=False
    )
    tw_open_minute: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    tw_close_minute: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    requires_agile: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=False
    )

    @property
    def location_key(self) -> str:
        return location_key(LOCATION_KEY_NODE, self.id)

    @property
    def is_urgent(self) -> bool:
        return self.priority == DeliveryPriority.URGENT

    def __repr__(self) -> str:  # pragma: no cover - debug aid
        return (
            f"<DeliveryNode id={self.id} ref={self.external_ref!r} "
            f"priority={self.priority.value} demand={self.demand_kg}kg>"
        )


# Distance et time matrix cach


class DistanceMatrixEntry(Base):

    __tablename__ = "distance_matrix"
    __table_args__ = (
        UniqueConstraint(
            "origin_key", "destination_key", name="uq_matrix_arc"
        ),
        CheckConstraint("distance_km >= 0", name="ck_matrix_distance_nonneg"),
        CheckConstraint(
            "free_flow_minutes >= 0", name="ck_matrix_freeflow_nonneg"
        ),
        Index("ix_matrix_origin", "origin_key"),
        Index("ix_matrix_destination", "destination_key"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    origin_key: Mapped[str] = mapped_column(String(48), nullable=False)
    destination_key: Mapped[str] = mapped_column(String(48), nullable=False)
    distance_km: Mapped[float] = mapped_column(Float, nullable=False)
    free_flow_minutes: Mapped[float] = mapped_column(Float, nullable=False)

    def __repr__(self) -> str:  # pragma: no cover - debug aid
        return (
            f"<Arc {self.origin_key}->{self.destination_key} "
            f"{self.distance_km:.2f}km {self.free_flow_minutes:.1f}min>"
        )


# geom <- lat/lon synchronisation


def _sync_geom(_mapper, _connection, target: GeoLocatedMixin) -> None:
    if target.latitude is not None and target.longitude is not None:
        # build PostGIS geography(Point, 4326) from lat/lon
        target.geom = WKTElement(
            f"POINT({target.longitude} {target.latitude})", srid=SRID_WGS84
        )


for _cls in (Depot, DeliveryNode):
    event.listen(_cls, "before_insert", _sync_geom, propagate=True)
    event.listen(_cls, "before_update", _sync_geom, propagate=True)


__all__ = [
    "Base",
    "TimestampMixin",
    "GeoLocatedMixin",
    "Depot",
    "Vehicle",
    "DeliveryNode",
    "DistanceMatrixEntry",
]
