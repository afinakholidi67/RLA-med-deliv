from __future__ import annotations

import datetime as dt
import enum
from typing import Optional

from sqlalchemy import (
    JSON,
    Boolean,
    DateTime,
    Enum as SAEnum,
    Float,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
)
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .models import Base

#:JSONB on PostgreSQL, plain JSON elsewhere (keeps the schema portable)
_JSON = JSON().with_variant(JSONB(), "postgresql")


def _utcnow() -> dt.datetime:
    return dt.datetime.now(dt.timezone.utc)


class JobStatus(str, enum.Enum):

    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"


class OptimizationJob(Base):

    __tablename__ = "optimization_jobs"
    __table_args__ = (Index("ix_jobs_status", "status"),)

    id: Mapped[str] = mapped_column(String(32), primary_key=True)
    status: Mapped[JobStatus] = mapped_column(
        SAEnum(JobStatus, name="job_status", native_enum=False),
        nullable=False,
        default=JobStatus.PENDING,
    )

    #for traceability / reproducibility
    depot_id: Mapped[int] = mapped_column(Integer, nullable=False)
    node_ids: Mapped[list[int]] = mapped_column(_JSON, nullable=False)
    vehicle_ids: Mapped[list[int]] = mapped_column(_JSON, nullable=False)
    config_overrides: Mapped[dict] = mapped_column(_JSON, nullable=False, default=dict)

    # timestamps
    submitted_at: Mapped[dt.datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=_utcnow
    )
    started_at: Mapped[Optional[dt.datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    finished_at: Mapped[Optional[dt.datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True
    )

    #result summary 
    total_cost: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    feasible: Mapped[Optional[bool]] = mapped_column(Boolean, nullable=True)
    objective: Mapped[Optional[dict]] = mapped_column(_JSON, nullable=True)
    unassigned: Mapped[Optional[list[int]]] = mapped_column(_JSON, nullable=True)
    error: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    route_assignments: Mapped[list["RouteAssignment"]] = relationship(
        back_populates="job",
        cascade="all, delete-orphan",
        order_by="RouteAssignment.sequence_index",
    )

    def __repr__(self) -> str:  # pragma: no cover - debug aid
        return f"<OptimizationJob id={self.id!r} status={self.status.value}>"


class RouteAssignment(Base):

    __tablename__ = "route_assignments"
    __table_args__ = (Index("ix_route_assign_job", "job_id"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    job_id: Mapped[str] = mapped_column(
        ForeignKey("optimization_jobs.id", ondelete="CASCADE"), nullable=False
    )
    sequence_index: Mapped[int] = mapped_column(Integer, nullable=False)

    vehicle_id: Mapped[int] = mapped_column(Integer, nullable=False)
    vehicle_label: Mapped[str] = mapped_column(String(64), nullable=False)
    visits: Mapped[list[int]] = mapped_column(_JSON, nullable=False)

    load_kg: Mapped[float] = mapped_column(Float, nullable=False)
    distance_km: Mapped[float] = mapped_column(Float, nullable=False)
    shift_minutes: Mapped[float] = mapped_column(Float, nullable=False)
    max_seal_minutes: Mapped[float] = mapped_column(Float, nullable=False)
    time_value: Mapped[float] = mapped_column(Float, nullable=False)
    distance_cost: Mapped[float] = mapped_column(Float, nullable=False)
    reliability: Mapped[float] = mapped_column(Float, nullable=False)
    feasible: Mapped[bool] = mapped_column(Boolean, nullable=False)

    job: Mapped["OptimizationJob"] = relationship(back_populates="route_assignments")

    def __repr__(self) -> str:  # pragma: no cover - debug aid
        return (
            f"<RouteAssignment job={self.job_id!r} seq={self.sequence_index} "
            f"vehicle={self.vehicle_label!r} stops={len(self.visits)}>"
        )


__all__ = ["JobStatus", "OptimizationJob", "RouteAssignment"]
