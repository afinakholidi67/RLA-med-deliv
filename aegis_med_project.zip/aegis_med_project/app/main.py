from __future__ import annotations

import logging
import multiprocessing
import os
import threading
from concurrent.futures import Future, ProcessPoolExecutor
from concurrent.futures.process import BrokenProcessPool
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Callable
from uuid import uuid4

from fastapi import Depends, FastAPI, HTTPException, Request, status
from fastapi.staticfiles import StaticFiles
from sqlalchemy import select
from sqlalchemy.orm import Session

from .api_schemas import (
    JobStatusResponse,
    JobSubmitResponse,
    ObjectiveBreakdownOut,
    OptimizeRequest,
    PrecomputeRequest,
    PrecomputeResponse,
    RouteAssignmentOut,
)
from .database import (
    create_all,
    dispose_engine,
    get_session,
    reset_pool_after_fork,
)
from .jobs_models import JobStatus, OptimizationJob, RouteAssignment
from .models import DeliveryNode, Depot, Vehicle
from .services import (
    fail_job_if_unfinished,
    recover_orphaned_jobs,
    run_optimization_job,
    warm_matrix_cache,
)

logger = logging.getLogger("aegis_med.api")

#worker process count. Defaults to CPU count (override with AEGIS_MAX_WORKERS)
_MAX_WORKERS: int = max(1, int(os.getenv("AEGIS_MAX_WORKERS", str(os.cpu_count() or 1))))

#guards rebuilds of a broken executor against concurrent requests
_executor_lock = threading.Lock()


def _build_executor() -> ProcessPoolExecutor:
    # spawn, not fork: forking a threaded server can deadlock
    ctx = multiprocessing.get_context("spawn")
    return ProcessPoolExecutor(
        max_workers=_MAX_WORKERS,
        mp_context=ctx,
        initializer=reset_pool_after_fork,
    )


@asynccontextmanager
async def lifespan(app: FastAPI):
    create_all()
    recovered = recover_orphaned_jobs()
    if recovered:
        logger.warning("orphan recovery: %d stranded job(s) marked FAILED", recovered)

    app.state.executor = _build_executor()
    logger.info("process pool started with %d worker(s)", _MAX_WORKERS)
    try:
        yield
    finally:
        app.state.executor.shutdown(wait=True)
        dispose_engine()
        logger.info("process pool drained and engine disposed")


app = FastAPI(
    title="AEGIS-MED Optimization API",
    version="0.4.0",
    description="Heterogeneous-fleet medical-logistics route optimization (ALNS).",
    lifespan=lifespan,
)

# Executor access + resilient submission


def get_executor(request: Request) -> ProcessPoolExecutor:
    executor = getattr(request.app.state, "executor", None)
    if executor is None:  # pragma: no cover - only before startup completes
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="optimization executor not initialized",
        )
    return executor


def _submit(app: FastAPI, fn: Callable[..., object], *args: object) -> Future:
    try:
        return app.state.executor.submit(fn, *args)
    except BrokenProcessPool:
        with _executor_lock:
            if getattr(app.state.executor, "_broken", False):
                logger.error("process pool broken; rebuilding")
                app.state.executor.shutdown(wait=False)
                app.state.executor = _build_executor()
        return app.state.executor.submit(fn, *args)


def _on_job_finished(job_id: str) -> Callable[[Future], None]:

    def _callback(future: Future) -> None:
        exc = future.exception()
        if exc is not None:
            logger.error("job %s worker failed: %r", job_id, exc)
            fail_job_if_unfinished(
                job_id, f"Worker process failure: {type(exc).__name__}: {exc}"
            )

    return _callback


def _on_precompute_finished(depot_id: int) -> Callable[[Future], None]:
    def _callback(future: Future) -> None:
        exc = future.exception()
        if exc is not None:
            logger.error("precompute (depot %s) failed: %r", depot_id, exc)
        else:
            logger.info("precompute (depot %s) warmed %s arcs of matrix", depot_id, future.result())

    return _callback


# Validation helper


def _ensure_entities_exist(
    session: Session,
    depot_id: int,
    node_ids: list[int],
    vehicle_ids: list[int],
) -> None:
    if session.get(Depot, depot_id) is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"depot {depot_id} not found",
        )
    found_nodes = set(
        session.scalars(select(DeliveryNode.id).where(DeliveryNode.id.in_(node_ids)))
    )
    missing_nodes = [n for n in node_ids if n not in found_nodes]
    if missing_nodes:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"delivery nodes not found: {missing_nodes}",
        )
    found_vehicles = set(
        session.scalars(select(Vehicle.id).where(Vehicle.id.in_(vehicle_ids)))
    )
    missing_vehicles = [v for v in vehicle_ids if v not in found_vehicles]
    if missing_vehicles:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"vehicles not found: {missing_vehicles}",
        )


# Endpoints


@app.get("/health", tags=["meta"])
def health() -> dict[str, str]:
    return {"status": "ok"}


@app.post(
    "/api/v1/optimize/submit",
    response_model=JobSubmitResponse,
    status_code=status.HTTP_202_ACCEPTED,
    tags=["optimize"],
)
def submit_optimization(
    payload: OptimizeRequest,
    request: Request,
    session: Session = Depends(get_session),
    executor: ProcessPoolExecutor = Depends(get_executor),
) -> JobSubmitResponse:
    _ensure_entities_exist(session, payload.depot_id, payload.node_ids, payload.vehicle_ids)

    job_id = uuid4().hex
    overrides = payload.config.to_overrides()
    job = OptimizationJob(
        id=job_id,
        status=JobStatus.PENDING,
        depot_id=payload.depot_id,
        node_ids=list(payload.node_ids),
        vehicle_ids=list(payload.vehicle_ids),
        config_overrides=overrides,
    )
    session.add(job)
    session.commit()  # must be visible to the worker's independent connection

    future = _submit(
        request.app,
        run_optimization_job,
        job_id,
        payload.depot_id,
        list(payload.node_ids),
        list(payload.vehicle_ids),
        overrides,
    )
    future.add_done_callback(_on_job_finished(job_id))

    return JobSubmitResponse(
        job_id=job_id, status=job.status, submitted_at=job.submitted_at
    )


@app.post(
    "/api/v1/matrix/precompute",
    response_model=PrecomputeResponse,
    status_code=status.HTTP_202_ACCEPTED,
    tags=["matrix"],
)
def precompute_matrix(
    payload: PrecomputeRequest,
    request: Request,
    session: Session = Depends(get_session),
    executor: ProcessPoolExecutor = Depends(get_executor),
) -> PrecomputeResponse:
    _ensure_entities_exist(session, payload.depot_id, payload.node_ids, payload.vehicle_ids)

    future = _submit(
        request.app,
        warm_matrix_cache,
        payload.depot_id,
        list(payload.node_ids),
        list(payload.vehicle_ids),
    )
    future.add_done_callback(_on_precompute_finished(payload.depot_id))

    return PrecomputeResponse(
        depot_id=payload.depot_id,
        node_count=len(payload.node_ids),
        vehicle_count=len(payload.vehicle_ids),
    )


@app.get(
    "/api/v1/optimize/status/{job_id}",
    response_model=JobStatusResponse,
    tags=["optimize"],
)
def get_optimization_status(
    job_id: str, session: Session = Depends(get_session)
) -> JobStatusResponse:
    job = session.get(OptimizationJob, job_id)
    if job is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail=f"job {job_id} not found"
        )

    response = JobStatusResponse(
        job_id=job.id,
        status=job.status,
        submitted_at=job.submitted_at,
        started_at=job.started_at,
        finished_at=job.finished_at,
        error=job.error,
        feasible=job.feasible,
        total_cost=job.total_cost,
        objective=ObjectiveBreakdownOut(**job.objective) if job.objective else None,
        unassigned=list(job.unassigned or []),
    )

    if job.status == JobStatus.COMPLETED:
        rows = session.scalars(
            select(RouteAssignment)
            .where(RouteAssignment.job_id == job_id)
            .order_by(RouteAssignment.sequence_index)
        ).all()
        response.routes = [RouteAssignmentOut.model_validate(r) for r in rows]

    return response


@app.get("/api/v1/depots", tags=["data"])
def list_depots(session: Session = Depends(get_session)) -> list[dict]:
    rows = session.scalars(select(Depot)).all()
    return [
        {
            "id": d.id,
            "name": d.name,
            "latitude": d.latitude,
            "longitude": d.longitude,
            "dispatch_minute": d.default_dispatch_minute,
        }
        for d in rows
    ]


@app.get("/api/v1/nodes", tags=["data"])
def list_nodes(session: Session = Depends(get_session)) -> list[dict]:
    rows = session.scalars(select(DeliveryNode)).all()
    return [
        {
            "id": n.id,
            "ref": n.external_ref,
            "name": n.name,
            "latitude": n.latitude,
            "longitude": n.longitude,
            "priority": n.priority.value,
            "demand_kg": n.demand_kg,
            "tw_open": n.tw_open_minute,
            "tw_close": n.tw_close_minute,
        }
        for n in rows
    ]


@app.get("/api/v1/vehicles", tags=["data"])
def list_vehicles(session: Session = Depends(get_session)) -> list[dict]:
    rows = session.scalars(select(Vehicle)).all()
    return [
        {
            "id": v.id,
            "label": v.label,
            "vehicle_class": v.vehicle_class.value,
            "payload_kg": v.payload_capacity_kg,
            "range_km": v.range_km,
        }
        for v in rows
    ]


@app.get("/api/v1/optimize/jobs", tags=["optimize"])
def list_jobs(limit: int = 50, session: Session = Depends(get_session)) -> list[dict]:
    rows = session.scalars(
        select(OptimizationJob)
        .order_by(OptimizationJob.submitted_at.desc())
        .limit(max(1, min(limit, 200)))
    ).all()
    return [
        {
            "job_id": j.id,
            "status": j.status.value,
            "submitted_at": j.submitted_at,
            "finished_at": j.finished_at,
            "total_cost": j.total_cost,
            "feasible": j.feasible,
            "node_count": len(j.node_ids or []),
        }
        for j in rows
    ]


@app.delete("/api/v1/optimize/jobs", tags=["optimize"])
def delete_all_jobs(session: Session = Depends(get_session)) -> dict:
    """Delete every job (and its routes via cascade). Running jobs are kept
    so an in-flight worker is never left writing to a deleted row."""
    rows = session.scalars(select(OptimizationJob)).all()
    deleted = 0
    skipped_running = 0
    for job in rows:
        if job.status == JobStatus.RUNNING:
            skipped_running += 1
            continue
        session.delete(job)  # cascade removes route_assignments
        deleted += 1
    session.commit()
    return {"deleted": deleted, "skipped_running": skipped_running}


_STATIC_DIR = Path(__file__).resolve().parent.parent / "static"
if _STATIC_DIR.is_dir():
    # Mounted last so API routes above take precedence over the SPA catch-all.
    app.mount("/", StaticFiles(directory=str(_STATIC_DIR), html=True), name="static")


__all__ = ["app"]
