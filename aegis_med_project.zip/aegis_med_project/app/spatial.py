from __future__ import annotations

import abc
from dataclasses import dataclass
from typing import TYPE_CHECKING, Iterable, Sequence

import numpy as np

from .constants import (
    DEFAULT_CIRCUITY_FACTOR,
    DEFAULT_FREE_FLOW_KMH,
    EARTH_RADIUS_KM,
    PEAK_TRAFFIC_MULTIPLIER,
    PEAK_WINDOW_CLOSE_MINUTES,
    PEAK_WINDOW_OPEN_MINUTES,
)

if TYPE_CHECKING:
    from sqlalchemy.orm import Session

_EPS = 1e-9

# Keyed location


@dataclass(frozen=True, slots=True)
class Location:

    key: str
    latitude: float
    longitude: float


def make_location(key: str, latitude: float, longitude: float) -> Location:
    return Location(key=key, latitude=latitude, longitude=longitude)


def locations_from_entities(entities: Iterable[object]) -> list[Location]:
    out: list[Location] = []
    for ent in entities:
        out.append(
            Location(
                key=getattr(ent, "location_key"),
                latitude=float(getattr(ent, "latitude")),
                longitude=float(getattr(ent, "longitude")),
            )
        )
    return out

# Geodesic base layer


def haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    phi1, phi2 = np.radians(lat1), np.radians(lat2)
    dphi = np.radians(lat2 - lat1)
    dlmb = np.radians(lon2 - lon1)
    a = np.sin(dphi / 2.0) ** 2 + np.cos(phi1) * np.cos(phi2) * np.sin(dlmb / 2.0) ** 2
    return float(2.0 * EARTH_RADIUS_KM * np.arcsin(np.sqrt(min(1.0, a))))


def _haversine_matrix(lats: np.ndarray, lons: np.ndarray) -> np.ndarray:
    lat = np.radians(lats)
    lon = np.radians(lons)
    dphi = lat[:, None] - lat[None, :]
    dlmb = lon[:, None] - lon[None, :]
    a = (
        np.sin(dphi / 2.0) ** 2
        + np.cos(lat)[:, None] * np.cos(lat)[None, :] * np.sin(dlmb / 2.0) ** 2
    )
    a = np.clip(a, 0.0, 1.0)
    gc = 2.0 * EARTH_RADIUS_KM * np.arcsin(np.sqrt(a))
    np.fill_diagonal(gc, 0.0)
    return gc


# Distance providers


class DistanceProvider(abc.ABC):

    name: str = "abstract"

    @abc.abstractmethod
    def table(
        self, locations: Sequence[Location]
    ) -> tuple[np.ndarray, np.ndarray]:  # pragma: no cover - interface
        raise NotImplementedError


@dataclass(slots=True)
class SyntheticDistanceProvider(DistanceProvider):

    circuity_factor: float = DEFAULT_CIRCUITY_FACTOR
    free_flow_kmh: float = DEFAULT_FREE_FLOW_KMH
    name: str = "synthetic"

    def __post_init__(self) -> None:
        if self.circuity_factor <= 0:
            raise ValueError("circuity_factor must be > 0")
        if self.free_flow_kmh <= 0:
            raise ValueError("free_flow_kmh must be > 0")

    def table(self, locations: Sequence[Location]) -> tuple[np.ndarray, np.ndarray]:
        if len(locations) < 1:
            raise ValueError("at least one location is required")
        lats = np.array([loc.latitude for loc in locations], dtype=float)
        lons = np.array([loc.longitude for loc in locations], dtype=float)
        geodesic = _haversine_matrix(lats, lons)
        distance_km = geodesic * self.circuity_factor
        free_flow_minutes = distance_km / self.free_flow_kmh * 60.0
        np.fill_diagonal(distance_km, 0.0)
        np.fill_diagonal(free_flow_minutes, 0.0)
        return distance_km, free_flow_minutes


@dataclass(slots=True)
class OSRMDistanceProvider(DistanceProvider):

    base_url: str
    profile: str = "driving"
    timeout_s: float = 30.0
    name: str = "osrm"

    def table(self, locations: Sequence[Location]) -> tuple[np.ndarray, np.ndarray]:
        import requests  # local import keeps the HTTP dependency optional at load

        coords = ";".join(f"{loc.longitude},{loc.latitude}" for loc in locations)
        url = f"{self.base_url.rstrip('/')}/table/v1/{self.profile}/{coords}"
        params = {"annotations": "duration,distance"}
        resp = requests.get(url, params=params, timeout=self.timeout_s)
        resp.raise_for_status()
        data = resp.json()
        if data.get("code") != "Ok":
            raise RuntimeError(
                f"OSRM table request failed: {data.get('code')} "
                f"{data.get('message', '')}".strip()
            )
        durations = np.asarray(data["durations"], dtype=float) / 60.0  # s -> min
        distances = np.asarray(data["distances"], dtype=float) / 1000.0  # m -> km
        np.fill_diagonal(distances, 0.0)
        np.fill_diagonal(durations, 0.0)
        return distances, durations


# Time-dependent (peak) travel model


def apply_peak_traffic(
    departure_minute: float,
    free_flow_minutes: float,
    *,
    peak_open: float = PEAK_WINDOW_OPEN_MINUTES,
    peak_close: float = PEAK_WINDOW_CLOSE_MINUTES,
    multiplier: float = PEAK_TRAFFIC_MULTIPLIER,
) -> float:
    if free_flow_minutes <= _EPS:
        return 0.0
    remaining = float(free_flow_minutes)
    t = float(departure_minute)
    elapsed = 0.0

    while remaining > _EPS:
        if peak_open <= t < peak_close:
            #inside the peak: progress is throttled until peak_close
            m = multiplier
            boundary = peak_close
        elif t < peak_open:
            #before the peak: full speed until peak_open
            m = 1.0
            boundary = peak_open
        else:
            #after the peak: full speed for the remainder no further boundary
            elapsed += remaining
            break

        real_available = boundary - t
        progress_available = real_available / m  #free-flow minutes earnable
        if progress_available + _EPS >= remaining:
            #trip completes within the current regime
            real_needed = remaining * m
            elapsed += real_needed
            remaining = 0.0
        else:
            #consume the regime up to the boundary and continue
            elapsed += real_available
            t = boundary
            remaining -= progress_available
    return elapsed
# Time-dependent matrix


@dataclass(slots=True)
class TimeDependentMatrix:

    keys: list[str]
    index: dict[str, int]
    distance_km: np.ndarray
    free_flow_minutes: np.ndarray
    provider_name: str = "unknown"
    peak_open: float = PEAK_WINDOW_OPEN_MINUTES
    peak_close: float = PEAK_WINDOW_CLOSE_MINUTES
    multiplier: float = PEAK_TRAFFIC_MULTIPLIER

    @property
    def size(self) -> int:
        return len(self.keys)

    def _resolve(self, key: str) -> int:
        try:
            return self.index[key]
        except KeyError as exc:
            raise KeyError(f"unknown location key: {key!r}") from exc

    def distance(self, origin_key: str, destination_key: str) -> float:
        return float(self.distance_km[self._resolve(origin_key), self._resolve(destination_key)])

    def free_flow(self, origin_key: str, destination_key: str) -> float:
        return float(
            self.free_flow_minutes[self._resolve(origin_key), self._resolve(destination_key)]
        )

    def travel_minutes(
        self, origin_key: str, destination_key: str, departure_minute: float
    ) -> float:
        ff = self.free_flow(origin_key, destination_key)
        return apply_peak_traffic(
            departure_minute,
            ff,
            peak_open=self.peak_open,
            peak_close=self.peak_close,
            multiplier=self.multiplier,
        )

    def arrival_minute(
        self, origin_key: str, destination_key: str, departure_minute: float
    ) -> float:
        return departure_minute + self.travel_minutes(
            origin_key, destination_key, departure_minute
        )

    def resolve_arc(
        self, origin_key: str, destination_key: str, departure_minute: float
    ) -> dict[str, float | bool | str]:
        ff = self.free_flow(origin_key, destination_key)
        travel = apply_peak_traffic(
            departure_minute,
            ff,
            peak_open=self.peak_open,
            peak_close=self.peak_close,
            multiplier=self.multiplier,
        )
        ratio = (travel / ff) if ff > _EPS else 1.0
        return {
            "origin_key": origin_key,
            "destination_key": destination_key,
            "departure_minute": float(departure_minute),
            "arrival_minute": float(departure_minute + travel),
            "distance_km": self.distance(origin_key, destination_key),
            "free_flow_minutes": float(ff),
            "travel_minutes": float(travel),
            "crosses_peak": bool(travel - ff > _EPS),
            "peak_inflation_ratio": float(ratio),
        }



def build_time_dependent_matrix(
    locations: Sequence[Location],
    provider: DistanceProvider | None = None,
) -> TimeDependentMatrix:
    if len(locations) < 2:
        raise ValueError("a matrix needs at least two locations")
    keys = [loc.key for loc in locations]
    if len(set(keys)) != len(keys):
        raise ValueError("location keys must be unique")

    provider = provider or SyntheticDistanceProvider()
    distance_km, free_flow_minutes = provider.table(locations)

    n = len(locations)
    if distance_km.shape != (n, n) or free_flow_minutes.shape != (n, n):
        raise ValueError("provider returned a matrix of the wrong shape")

    return TimeDependentMatrix(
        keys=keys,
        index={k: i for i, k in enumerate(keys)},
        distance_km=np.ascontiguousarray(distance_km, dtype=float),
        free_flow_minutes=np.ascontiguousarray(free_flow_minutes, dtype=float),
        provider_name=getattr(provider, "name", "unknown"),
    )


def persist_matrix(session: "Session", matrix: TimeDependentMatrix) -> int:
    from sqlalchemy import delete, insert  # local import: keeps spatial ORM-light

    from .models import DistanceMatrixEntry

    keys = matrix.keys
    session.execute(
        delete(DistanceMatrixEntry).where(
            DistanceMatrixEntry.origin_key.in_(keys),
            DistanceMatrixEntry.destination_key.in_(keys),
        )
    )

    dist = matrix.distance_km
    free_flow = matrix.free_flow_minutes
    mappings: list[dict[str, object]] = []
    for i, origin in enumerate(keys):
        row_dist = dist[i]
        row_ff = free_flow[i]
        for j, destination in enumerate(keys):
            if i == j:
                continue
            mappings.append(
                {
                    "origin_key": origin,
                    "destination_key": destination,
                    "distance_km": float(row_dist[j]),
                    "free_flow_minutes": float(row_ff[j]),
                }
            )

    if mappings:
        # Core bulk INSERT (executemany) bypasses the ORM unit of work
        session.execute(insert(DistanceMatrixEntry), mappings)
    return len(mappings)


def load_matrix(session: "Session", keys: Sequence[str]) -> TimeDependentMatrix:
    from .models import DistanceMatrixEntry  #local import avoids ORM cycle

    keys = list(keys)
    index = {k: i for i, k in enumerate(keys)}
    n = len(keys)
    dist = np.zeros((n, n), dtype=float)
    ff = np.zeros((n, n), dtype=float)
    seen = np.zeros((n, n), dtype=bool)
    np.fill_diagonal(seen, True)

    entries = (
        session.query(DistanceMatrixEntry)
        .filter(
            DistanceMatrixEntry.origin_key.in_(keys),
            DistanceMatrixEntry.destination_key.in_(keys),
        )
        .all()
    )
    for e in entries:
        i = index.get(e.origin_key)
        j = index.get(e.destination_key)
        if i is None or j is None:
            continue
        dist[i, j] = e.distance_km
        ff[i, j] = e.free_flow_minutes
        seen[i, j] = True

    if not seen.all():
        missing = int((~seen).sum())
        raise ValueError(f"distance_matrix cache is incomplete: {missing} arcs missing")

    return TimeDependentMatrix(
        keys=keys,
        index=index,
        distance_km=dist,
        free_flow_minutes=ff,
        provider_name="cache",
    )


__all__ = [
    "Location",
    "make_location",
    "locations_from_entities",
    "haversine_km",
    "DistanceProvider",
    "SyntheticDistanceProvider",
    "OSRMDistanceProvider",
    "apply_peak_traffic",
    "TimeDependentMatrix",
    "build_time_dependent_matrix",
    "persist_matrix",
    "load_matrix",
]
