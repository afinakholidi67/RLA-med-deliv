from __future__ import annotations

from dataclasses import dataclass, field, replace
from typing import TYPE_CHECKING, Iterable, Mapping, Optional, Sequence

from .constants import (
    DEFAULT_STAGNATION_MINUTES,
    DIGITAL_SEAL_MINUTES,
    MAX_SHIFT_MINUTES,
    RISK_DECAY_MINUTES,
    SEAL_RISK_THRESHOLD_MINUTES,
    WEIGHT_DISTANCE_GAMMA,
    WEIGHT_RELIABILITY_ALPHA,
    WEIGHT_TIME_BETA,
    DeliveryPriority,
    VehicleClass,
    seal_risk,
)
from .spatial import TimeDependentMatrix

if TYPE_CHECKING:  # pragma: no cover - typing only
    from .models import Depot, DeliveryNode, Vehicle

_EPS = 1e-6


# ===========================================================================
# Problem specs (immutable, ORM-decoupled)
# ===========================================================================


@dataclass(frozen=True, slots=True)
class VehicleSpec:

    id: int
    label: str
    vehicle_class: VehicleClass
    payload_capacity_kg: float
    range_km: float
    cost_per_km: float
    fixed_dispatch_cost: float = 0.0

    @property
    def is_agile(self) -> bool:
        return self.vehicle_class == VehicleClass.SMALL

    @classmethod
    def from_orm(cls, vehicle: "Vehicle") -> "VehicleSpec":
        return cls(
            id=int(vehicle.id),
            label=str(vehicle.label),
            vehicle_class=vehicle.vehicle_class,
            payload_capacity_kg=float(vehicle.payload_capacity_kg),
            range_km=float(vehicle.range_km),
            cost_per_km=float(vehicle.cost_per_km),
            fixed_dispatch_cost=float(vehicle.fixed_dispatch_cost),
        )


@dataclass(frozen=True, slots=True)
class NodeSpec:

    id: int
    key: str
    demand_kg: float
    service_time: float
    priority: DeliveryPriority = DeliveryPriority.STANDARD
    tw_open: Optional[float] = None
    tw_close: Optional[float] = None
    requires_agile: bool = False

    @property
    def is_urgent(self) -> bool:
        return self.priority == DeliveryPriority.URGENT

    @classmethod
    def from_orm(cls, node: "DeliveryNode") -> "NodeSpec":
        return cls(
            id=int(node.id),
            key=str(node.location_key),
            demand_kg=float(node.demand_kg),
            service_time=float(node.service_time_minutes),
            priority=node.priority,
            tw_open=(None if node.tw_open_minute is None else float(node.tw_open_minute)),
            tw_close=(None if node.tw_close_minute is None else float(node.tw_close_minute)),
            requires_agile=bool(node.requires_agile),
        )


@dataclass(frozen=True, slots=True)
class DepotSpec:

    id: int
    key: str
    dispatch_minute: float

    @classmethod
    def from_orm(cls, depot: "Depot") -> "DepotSpec":
        return cls(
            id=int(depot.id),
            key=str(depot.location_key),
            dispatch_minute=float(depot.default_dispatch_minute),
        )


# ===========================================================================
# Engine configuration
# ===========================================================================


@dataclass(frozen=True, slots=True)
class EngineConfig:

    # --- Multi-objective weights ---
    alpha: float = WEIGHT_RELIABILITY_ALPHA  # reliability (risk + window)
    beta: float = WEIGHT_TIME_BETA           # active time
    gamma: float = WEIGHT_DISTANCE_GAMMA     # operational distance cost

    # --- Penalties ---
    #: Cost charged per still-unassigned node, forcing full insertion.
    unassigned_penalty: float = 1.0e6
    #: Per-minute lateness penalty folded into R(S) (then weighted by alpha).
    window_violation_weight: float = 50.0

    # --- Seal / stagnation ---
    default_stagnation_minutes: float = DEFAULT_STAGNATION_MINUTES
    seal_risk_threshold: float = SEAL_RISK_THRESHOLD_MINUTES
    risk_decay: float = RISK_DECAY_MINUTES
    seal_limit_minutes: float = DIGITAL_SEAL_MINUTES

    # --- Feasibility switches ---
    max_shift_minutes: float = MAX_SHIFT_MINUTES
    #: If True, on-duty waiting (idling for a window to open) counts against the
    #: 570-min shift cap. Default True = conservative real-world reading.
    shift_counts_waiting: bool = True
    enforce_capacity: bool = True
    enforce_range: bool = True
    enforce_shift: bool = True
    enforce_seal: bool = True
    enforce_agile_access: bool = True

    # --- Search controls (used in Part 2) ---
    random_seed: int = 42
    sa_start_temperature: float = 0.0  # 0 -> auto-calibrate from seed cost
    sa_cooling_rate: float = 0.99975
    sa_min_temperature: float = 1.0e-3
    max_iterations: int = 25_000
    segment_size: int = 100
    reaction_factor: float = 0.1
    score_new_best: float = 33.0
    score_improved: float = 13.0
    score_accepted: float = 9.0
    min_removal_fraction: float = 0.10
    max_removal_fraction: float = 0.40
    shaw_weight_distance: float = 9.0
    shaw_weight_time: float = 3.0
    shaw_weight_demand: float = 2.0
    regret_k: int = 3


# ===========================================================================
# Problem instance
# ===========================================================================


@dataclass(slots=True)
class ProblemInstance:

    depot: DepotSpec
    nodes: Mapping[int, NodeSpec]
    vehicles: tuple[VehicleSpec, ...]
    matrix: TimeDependentMatrix
    config: EngineConfig = field(default_factory=EngineConfig)

    def node(self, node_id: int) -> NodeSpec:
        return self.nodes[node_id]

    @property
    def node_ids(self) -> tuple[int, ...]:
        return tuple(self.nodes.keys())

    @property
    def urgent_ids(self) -> tuple[int, ...]:
        return tuple(nid for nid, n in self.nodes.items() if n.is_urgent)

    def total_demand(self) -> float:
        return sum(n.demand_kg for n in self.nodes.values())

    def total_capacity(self) -> float:
        return sum(v.payload_capacity_kg for v in self.vehicles)

    @classmethod
    def from_entities(
        cls,
        depot: "Depot",
        nodes: Iterable["DeliveryNode"],
        vehicles: Iterable["Vehicle"],
        matrix: TimeDependentMatrix,
        config: EngineConfig | None = None,
    ) -> "ProblemInstance":
        node_specs = {int(n.id): NodeSpec.from_orm(n) for n in nodes}
        vehicle_specs = tuple(VehicleSpec.from_orm(v) for v in vehicles)
        return cls(
            depot=DepotSpec.from_orm(depot),
            nodes=node_specs,
            vehicles=vehicle_specs,
            matrix=matrix,
            config=config or EngineConfig(),
        )


# ===========================================================================
# State: Route + RouteEvaluation
# ===========================================================================


@dataclass(frozen=True, slots=True)
class Route:

    vehicle: VehicleSpec
    visits: tuple[int, ...] = ()
    stagnation_time: float = DEFAULT_STAGNATION_MINUTES

    def with_visits(self, visits: Sequence[int]) -> "Route":
        return replace(self, visits=tuple(visits))

    def with_stagnation(self, stagnation_time: float) -> "Route":
        return replace(self, stagnation_time=float(stagnation_time))

    @property
    def is_empty(self) -> bool:
        return len(self.visits) == 0

    def __len__(self) -> int:
        return len(self.visits)


@dataclass(frozen=True, slots=True)
class RouteEvaluation:

    feasible: bool
    infeasibility: tuple[str, ...]
    load_kg: float
    distance_km: float
    drive_minutes: float
    service_minutes: float
    wait_minutes: float
    shift_duration: float          # value checked against MAX_SHIFT_MINUTES
    return_minute: float           # absolute minute-of-day back at depot
    arrivals: tuple[float, ...]    # absolute arrival minute per visit
    seal_times: tuple[float, ...]  # stagnation + elapsed-since-dispatch per visit
    max_seal_time: float
    seal_risk_sum: float           # sum of exp risk over visits
    window_penalty_minutes: float  # total lateness minutes
    reliability: float             # R(route) = seal_risk_sum + w_win * lateness
    time_value: float              # T(route) = active time incl. waiting
    distance_cost: float           # D(route) = dist*cost_per_km + fixed cost


# ===========================================================================
# Forward time propagation (Solomon-style)
# ===========================================================================


def propagate(route: Route, instance: ProblemInstance) -> RouteEvaluation:
    cfg = instance.config
    depot = instance.depot
    matrix = instance.matrix
    veh = route.vehicle
    dispatch = depot.dispatch_minute

    if route.is_empty:
        # Unused vehicle: no travel, no fixed cost, trivially feasible.
        return RouteEvaluation(
            feasible=True,
            infeasibility=(),
            load_kg=0.0,
            distance_km=0.0,
            drive_minutes=0.0,
            service_minutes=0.0,
            wait_minutes=0.0,
            shift_duration=0.0,
            return_minute=dispatch,
            arrivals=(),
            seal_times=(),
            max_seal_time=0.0,
            seal_risk_sum=0.0,
            window_penalty_minutes=0.0,
            reliability=0.0,
            time_value=0.0,
            distance_cost=0.0,
        )

    load = 0.0
    distance = 0.0
    drive = 0.0
    service = 0.0
    wait = 0.0
    seal_risk_sum = 0.0
    window_penalty = 0.0
    max_seal = 0.0
    arrivals: list[float] = []
    seal_times: list[float] = []
    agile_violation = False

    t = dispatch
    prev_key = depot.key

    for node_id in route.visits:
        node = instance.nodes[node_id]

        leg = matrix.travel_minutes(prev_key, node.key, t)
        leg_dist = matrix.distance(prev_key, node.key)
        drive += leg
        distance += leg_dist
        arrive = t + leg
        arrivals.append(arrive)

        # Time-window handling: wait if early, penalise if late.
        if node.tw_open is not None and arrive < node.tw_open:
            wait += node.tw_open - arrive
            service_start = node.tw_open
        else:
            service_start = arrive
        if node.tw_close is not None and service_start > node.tw_close + _EPS:
            window_penalty += service_start - node.tw_close

        # Seal clock (decoupled): stagnation + elapsed-since-dispatch.
        elapsed = arrive - dispatch
        # seal clock decoupled from shift: dock dwell + elapsed since dispatch
        seal_time = route.stagnation_time + elapsed
        seal_times.append(seal_time)
        if seal_time > max_seal:
            max_seal = seal_time
        seal_risk_sum += seal_risk(
            elapsed,
            route.stagnation_time,
            threshold=cfg.seal_risk_threshold,
            decay=cfg.risk_decay,
        )

        load += node.demand_kg
        if node.requires_agile and not veh.is_agile:
            agile_violation = True

        # Advance to service completion and move on.
        service += node.service_time
        t = service_start + node.service_time
        prev_key = node.key

    # Return leg to depot (cargo delivered -> no seal check on the return).
    back = matrix.travel_minutes(prev_key, depot.key, t)
    back_dist = matrix.distance(prev_key, depot.key)
    drive += back
    distance += back_dist
    return_minute = t + back

    time_value = return_minute - dispatch  # drive + wait + service
    shift_duration = time_value if cfg.shift_counts_waiting else (drive + service)
    reliability = seal_risk_sum + cfg.window_violation_weight * window_penalty
    distance_cost = distance * veh.cost_per_km + veh.fixed_dispatch_cost

    infeasibility: list[str] = []
    if cfg.enforce_capacity and load > veh.payload_capacity_kg + _EPS:
        infeasibility.append(
            f"capacity {load:.1f}kg > {veh.payload_capacity_kg:.1f}kg"
        )
    if cfg.enforce_range and distance > veh.range_km + _EPS:
        infeasibility.append(f"range {distance:.1f}km > {veh.range_km:.1f}km")
    if cfg.enforce_shift and shift_duration > cfg.max_shift_minutes + _EPS:
        infeasibility.append(
            f"shift {shift_duration:.1f}min > {cfg.max_shift_minutes:.1f}min"
        )
    if cfg.enforce_seal and max_seal > cfg.seal_limit_minutes + _EPS:
        infeasibility.append(
            f"seal {max_seal:.1f}min > {cfg.seal_limit_minutes:.1f}min"
        )
    if cfg.enforce_agile_access and agile_violation:
        infeasibility.append("agile-only node assigned to a box truck")

    return RouteEvaluation(
        feasible=not infeasibility,
        infeasibility=tuple(infeasibility),
        load_kg=load,
        distance_km=distance,
        drive_minutes=drive,
        service_minutes=service,
        wait_minutes=wait,
        shift_duration=shift_duration,
        return_minute=return_minute,
        arrivals=tuple(arrivals),
        seal_times=tuple(seal_times),
        max_seal_time=max_seal,
        seal_risk_sum=seal_risk_sum,
        window_penalty_minutes=window_penalty,
        reliability=reliability,
        time_value=time_value,
        distance_cost=distance_cost,
    )


# ===========================================================================
# Objective Z(S)
# ===========================================================================


@dataclass(frozen=True, slots=True)
class ObjectiveBreakdown:

    reliability: float        # R(S) raw
    time: float               # T(S) raw minutes
    distance_cost: float      # D(S) raw monetary
    unassigned_count: int
    weighted_reliability: float
    weighted_time: float
    weighted_distance: float
    unassigned_penalty: float
    total: float

    def __float__(self) -> float:  # pragma: no cover - convenience
        return self.total


def aggregate_objective(
    evaluations: Sequence[RouteEvaluation],
    unassigned_count: int,
    config: EngineConfig,
) -> ObjectiveBreakdown:
    reliability = sum(e.reliability for e in evaluations)
    time_total = sum(e.time_value for e in evaluations)
    distance_cost = sum(e.distance_cost for e in evaluations)

    weighted_reliability = config.alpha * reliability
    weighted_time = config.beta * time_total
    weighted_distance = config.gamma * distance_cost
    unassigned_penalty = config.unassigned_penalty * unassigned_count
    total = (
        weighted_reliability
        + weighted_time
        + weighted_distance
        + unassigned_penalty
    )
    return ObjectiveBreakdown(
        reliability=reliability,
        time=time_total,
        distance_cost=distance_cost,
        unassigned_count=unassigned_count,
        weighted_reliability=weighted_reliability,
        weighted_time=weighted_time,
        weighted_distance=weighted_distance,
        unassigned_penalty=unassigned_penalty,
        total=total,
    )


# ===========================================================================
# Solution
# ===========================================================================


@dataclass(frozen=True, slots=True)
class Solution:

    routes: tuple[Route, ...]
    unassigned: tuple[int, ...]
    evaluations: tuple[RouteEvaluation, ...]
    objective: ObjectiveBreakdown
    feasible: bool

    @property
    def cost(self) -> float:
        return self.objective.total

    @property
    def assigned_count(self) -> int:
        return sum(len(r.visits) for r in self.routes)

    @classmethod
    def build(
        cls,
        routes: Sequence[Route],
        unassigned: Sequence[int],
        instance: ProblemInstance,
    ) -> "Solution":
        routes_t = tuple(routes)
        evaluations = tuple(propagate(r, instance) for r in routes_t)
        unassigned_t = tuple(unassigned)
        objective = aggregate_objective(
            evaluations, len(unassigned_t), instance.config
        )
        feasible = not unassigned_t and all(e.feasible for e in evaluations)
        return cls(
            routes=routes_t,
            unassigned=unassigned_t,
            evaluations=evaluations,
            objective=objective,
            feasible=feasible,
        )

    @classmethod
    def empty(cls, instance: ProblemInstance) -> "Solution":
        stagnation = instance.config.default_stagnation_minutes
        routes = tuple(
            Route(vehicle=v, visits=(), stagnation_time=stagnation)
            for v in instance.vehicles
        )
        return cls.build(routes, instance.node_ids, instance)

    def with_routes(
        self,
        routes: Sequence[Route],
        unassigned: Sequence[int],
        instance: ProblemInstance,
    ) -> "Solution":
        return Solution.build(routes, unassigned, instance)

    def replace_route(
        self, index: int, route: Route, instance: ProblemInstance
    ) -> "Solution":
        new_routes = list(self.routes)
        new_routes[index] = route
        new_evals = list(self.evaluations)
        new_evals[index] = propagate(route, instance)
        objective = aggregate_objective(
            new_evals, len(self.unassigned), instance.config
        )
        feasible = not self.unassigned and all(e.feasible for e in new_evals)
        return Solution(
            routes=tuple(new_routes),
            unassigned=self.unassigned,
            evaluations=tuple(new_evals),
            objective=objective,
            feasible=feasible,
        )

    def describe(self) -> str:  # pragma: no cover - human-readable summary
        ob = self.objective
        lines = [
            f"Solution  Z={ob.total:,.2f}  feasible={self.feasible}",
            f"  R={ob.reliability:.4f} (aR={ob.weighted_reliability:,.2f})  "
            f"T={ob.time:.1f}min (bT={ob.weighted_time:,.1f})  "
            f"D={ob.distance_cost:.2f} (gD={ob.weighted_distance:,.2f})  "
            f"unassigned={ob.unassigned_count}",
        ]
        for i, (r, e) in enumerate(zip(self.routes, self.evaluations)):
            if r.is_empty:
                continue
            flag = "OK" if e.feasible else "INFEASIBLE: " + "; ".join(e.infeasibility)
            lines.append(
                f"  [{i}] {r.vehicle.label} ({r.vehicle.vehicle_class.value}) "
                f"visits={list(r.visits)} load={e.load_kg:.0f}kg "
                f"dist={e.distance_km:.1f}km shift={e.shift_duration:.0f}min "
                f"maxSeal={e.max_seal_time:.0f}min [{flag}]"
            )
        return "\n".join(lines)


__all__ = [
    "VehicleSpec",
    "NodeSpec",
    "DepotSpec",
    "EngineConfig",
    "ProblemInstance",
    "Route",
    "RouteEvaluation",
    "propagate",
    "ObjectiveBreakdown",
    "aggregate_objective",
    "Solution",
]
