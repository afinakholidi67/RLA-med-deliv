from __future__ import annotations

import enum
import math
from typing import Final

#temporal constants (minutes)

#F — the "24-Hour Digital Seal" hard limit measured from load completion 
DIGITAL_SEAL_MINUTES: Final[int] = 1440

#mandated safety buffer subtracted from F inside the risk penalty R(v).
SEAL_SAFETY_BUFFER_MINUTES: Final[int] = 120

#arrival time beyond which R(v) starts to ramp: (F - 120) = 1320 min.
SEAL_RISK_THRESHOLD_MINUTES: Final[int] = (
    DIGITAL_SEAL_MINUTES - SEAL_SAFETY_BUFFER_MINUTES
)

#: Denominator scale (in minutes) of the exponential in R(v).
RISK_DECAY_MINUTES: Final[int] = 60

#hard driver-shift cap (9.5 h). This is the binding bottleneck, typically
#violated long before the 1440-min seal limit.
MAX_SHIFT_MINUTES: Final[int] = 570

#traffic peak window (minutes from local midnight)


DAY_MINUTES: Final[int] = 1440

#:p t window open: 08:30.
PEAK_WINDOW_OPEN_MINUTES: Final[int] = 8 * 60 + 30  # 510

#:peak trafic window close: 12:00.
PEAK_WINDOW_CLOSE_MINUTES: Final[int] = 12 * 60  # 720

#time inflation factor applied inside the peak window.
PEAK_TRAFFIC_MULTIPLIER: Final[float] = 1.4

#: Default morning delivery window (coincides with the peak window) applied to
#: the ~65% of nodes that are time-constrained.
DEFAULT_TW_OPEN_MINUTES: Final[int] = PEAK_WINDOW_OPEN_MINUTES   # 510
DEFAULT_TW_CLOSE_MINUTES: Final[int] = PEAK_WINDOW_CLOSE_MINUTES  # 720

#default depot dispatch minute = t0 of the seal  shift clocks (08:00)
DEFAULT_DISPATCH_MINUTES: Final[int] = 8 * 60  # 480

#default on site service duration when a node does not specify its own
DEFAULT_SERVICE_MINUTES: Final[float] = 10.0

#default cargo dock-dwell before dispatch (minutes) feeding the seal clock
#0.0 reproduces the legacy behaviour; raise per-route to activate R(v)
DEFAULT_STAGNATION_MINUTES: Final[float] = 0.

#multi objective weights (lexicographic by magnitude: alpha > beta > gamma)

WEIGHT_RELIABILITY_ALPHA: Final[float] = 1000.0
WEIGHT_TIME_BETA: Final[float] = 10.0
WEIGHT_DISTANCE_GAMMA: Final[float] = 1.0

#road-network synthesis defaults


# mean Earth radius (WGS-84 authalic) in km, for the haversine base layer
EARTH_RADIUS_KM: Final[float] = 6371.0088

#circuity factor straight-line geodesic -> drivable road distance
#empirical urban range ~1.3–1.5; used only by the synthetic provider
DEFAULT_CIRCUITY_FACTOR: Final[float] = 1.417

#freeflow (off-peak) effective network speed (km/h) for the synthetic
#provider. Peak times are derived by applying PEAK_TRAFFIC_MULTIPLIER
DEFAULT_FREE_FLOW_KMH: Final[float] = 32.0

#: WGS-84 spatial reference identifier used for all PostGIS geography columns.
SRID_WGS84: Final[int] = 4326

#location-key prefixes used to address depots and nodes in the unified
#distance-matrix index (so depot and delivery rows share one keyspace).
LOCATION_KEY_DEPOT: Final[str] = "depot"
LOCATION_KEY_NODE: Final[str] = "node"


def location_key(prefix: str, entity_id: int) -> str:
    return f"{prefix}:{entity_id}"


# Enumerations (shared by ORM + Pydantic str-backed for clean JSON et DB)



class VehicleClass(str, enum.Enum):

    SMALL = "small"  # 18 agile electric / small-diesel units (~550 kg, 160–350 km)
    LARGE = "large"  # 7 box trucks (2.5–4.0 t, 600–800 km)


class PowertrainType(str, enum.Enum):
    ELECTRIC = "electric"
    DIESEL = "diesel"


class NodeType(str, enum.Enum):
    DEPOT = "depot"
    PHARMACY = "pharmacy"
    CLINIC = "clinic"


class DeliveryPriority(str, enum.Enum):

    URGENT = "urgent"
    STANDARD = "standard"


#each class validation bounds (derived from the operational analysis report)

#: (min, max) payload in kg accepted per vehicle class. A small tolerance band
#:is included so a 552 kg unit is not rejected over a "~550 kg" datasheet.
PAYLOAD_BOUNDS_KG: Final[dict[VehicleClass, tuple[float, float]]] = {
    VehicleClass.SMALL: (1.0, 700.0),
    VehicleClass.LARGE: (550.0, 4000.0),
}

#(min, max) operating range in km accepted per vehicle class
RANGE_BOUNDS_KM: Final[dict[VehicleClass, tuple[float, float]]] = {
    VehicleClass.SMALL: (120.0, 400.0),
    VehicleClass.LARGE: (550.0, 900.0),
}


#seal-clock math (single source of truth for R(v) and the hard seal)


def seal_elapsed_minutes(
    arrival_from_dispatch_minutes: float,
    stagnation_minutes: float = DEFAULT_STAGNATION_MINUTES,
) -> float:
    return float(stagnation_minutes) + float(arrival_from_dispatch_minutes)


def seal_risk(
    arrival_from_dispatch_minutes: float,
    stagnation_minutes: float = DEFAULT_STAGNATION_MINUTES,
    *,
    threshold: float = SEAL_RISK_THRESHOLD_MINUTES,
    decay: float = RISK_DECAY_MINUTES,
) -> float:
    seal_time = seal_elapsed_minutes(arrival_from_dispatch_minutes, stagnation_minutes)
    return max(0.0, math.exp((seal_time - threshold) / decay))


def seal_breached(
    arrival_from_dispatch_minutes: float,
    stagnation_minutes: float = DEFAULT_STAGNATION_MINUTES,
    *,
    limit: float = DIGITAL_SEAL_MINUTES,
) -> bool:
    return (
        seal_elapsed_minutes(arrival_from_dispatch_minutes, stagnation_minutes)
        > float(limit)
    )

__all__ = [
    "DIGITAL_SEAL_MINUTES",
    "SEAL_SAFETY_BUFFER_MINUTES",
    "SEAL_RISK_THRESHOLD_MINUTES",
    "RISK_DECAY_MINUTES",
    "MAX_SHIFT_MINUTES",
    "DAY_MINUTES",
    "PEAK_WINDOW_OPEN_MINUTES",
    "PEAK_WINDOW_CLOSE_MINUTES",
    "PEAK_TRAFFIC_MULTIPLIER",
    "DEFAULT_TW_OPEN_MINUTES",
    "DEFAULT_TW_CLOSE_MINUTES",
    "DEFAULT_DISPATCH_MINUTES",
    "DEFAULT_SERVICE_MINUTES",
    "DEFAULT_STAGNATION_MINUTES",
    "WEIGHT_RELIABILITY_ALPHA",
    "WEIGHT_TIME_BETA",
    "WEIGHT_DISTANCE_GAMMA",
    "EARTH_RADIUS_KM",
    "DEFAULT_CIRCUITY_FACTOR",
    "DEFAULT_FREE_FLOW_KMH",
    "SRID_WGS84",
    "LOCATION_KEY_DEPOT",
    "LOCATION_KEY_NODE",
    "location_key",
    "VehicleClass",
    "PowertrainType",
    "NodeType",
    "DeliveryPriority",
    "PAYLOAD_BOUNDS_KG",
    "RANGE_BOUNDS_KM",
    "seal_elapsed_minutes",
    "seal_risk",
    "seal_breached",
]
