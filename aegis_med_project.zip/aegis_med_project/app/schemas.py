from __future__ import annotations

from typing import Annotated, Optional

from pydantic import BaseModel, ConfigDict, Field, model_validator

from .constants import (
    DEFAULT_CIRCUITY_FACTOR,
    DEFAULT_DISPATCH_MINUTES,
    DEFAULT_FREE_FLOW_KMH,
    DEFAULT_SERVICE_MINUTES,
    DEFAULT_TW_CLOSE_MINUTES,
    DEFAULT_TW_OPEN_MINUTES,
    PAYLOAD_BOUNDS_KG,
    RANGE_BOUNDS_KM,
    DeliveryPriority,
    NodeType,
    PowertrainType,
    VehicleClass,
)

#Constrained primitive aliases

Latitude = Annotated[float, Field(ge=-90.0, le=90.0)]
Longitude = Annotated[float, Field(ge=-180.0, le=180.0)]
MinuteOfDay = Annotated[int, Field(ge=0, le=1440)]
NonNegFloat = Annotated[float, Field(ge=0.0)]
PosFloat = Annotated[float, Field(gt=0.0)]

# Time window value object


class TimeWindow(BaseModel):

    model_config = ConfigDict(frozen=True)

    open_minute: MinuteOfDay
    close_minute: MinuteOfDay

    @model_validator(mode="after")
    def _ordered(self) -> "TimeWindow":
        if self.close_minute <= self.open_minute:
            raise ValueError(
                "close_minute must be strictly after open_minute "
                f"(got open={self.open_minute}, close={self.close_minute})"
            )
        return self

    @property
    def duration_minutes(self) -> int:
        return self.close_minute - self.open_minute

    def contains(self, minute: float) -> bool:
        return self.open_minute <= minute < self.close_minute

# Vehicle

class VehicleBase(BaseModel):
    label: str = Field(min_length=1, max_length=64)
    vehicle_class: VehicleClass
    powertrain: PowertrainType
    payload_capacity_kg: PosFloat
    range_km: PosFloat
    cost_per_km: NonNegFloat = 0.0
    fixed_dispatch_cost: NonNegFloat = 0.0
    avg_speed_kmh: Optional[PosFloat] = None
    active: bool = True
    depot_id: int = Field(gt=0)

    @model_validator(mode="after")
    def _class_consistency(self) -> "VehicleBase":
        plo, phi = PAYLOAD_BOUNDS_KG[self.vehicle_class]
        if not (plo <= self.payload_capacity_kg <= phi):
            raise ValueError(
                f"{self.vehicle_class.value} payload {self.payload_capacity_kg} kg "
                f"outside permitted band [{plo}, {phi}] kg"
            )
        rlo, rhi = RANGE_BOUNDS_KM[self.vehicle_class]
        if not (rlo <= self.range_km <= rhi):
            raise ValueError(
                f"{self.vehicle_class.value} range {self.range_km} km "
                f"outside permitted band [{rlo}, {rhi}] km"
            )
        #electric units are typically the short range agile small fleet warn
        # via validation only on hard physical impossibility (handled above).
        return self


class VehicleCreate(VehicleBase):
    pass


class VehicleRead(VehicleBase):

    model_config = ConfigDict(from_attributes=True)

    id: int


# Depot


class DepotBase(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    latitude: Latitude
    longitude: Longitude
    # t0 of the seal & shift clocks (loading completion + sealing).
    default_dispatch_minute: MinuteOfDay = DEFAULT_DISPATCH_MINUTES


class DepotCreate(DepotBase):
    pass


class DepotRead(DepotBase):

    model_config = ConfigDict(from_attributes=True)

    id: int


# Delivery node


class DeliveryNodeBase(BaseModel):
    external_ref: str = Field(min_length=1, max_length=64)
    name: str = Field(min_length=1, max_length=160)
    node_type: NodeType
    latitude: Latitude
    longitude: Longitude
    demand_kg: NonNegFloat = 0.0
    service_time_minutes: NonNegFloat = DEFAULT_SERVICE_MINUTES
    priority: DeliveryPriority = DeliveryPriority.STANDARD
    is_time_constrained: bool = False
    tw_open_minute: Optional[MinuteOfDay] = None
    tw_close_minute: Optional[MinuteOfDay] = None
    requires_agile: bool = False

    @model_validator(mode="after")
    def _normalise_window_and_type(self) -> "DeliveryNodeBase":
        if self.node_type == NodeType.DEPOT:
            raise ValueError(
                "node_type DEPOT is not a delivery point; use DepotCreate"
            )

        has_open = self.tw_open_minute is not None
        has_close = self.tw_close_minute is not None

        if self.is_time_constrained:
            # Default to the canonical 08:30–12:00 morning window if omitted.
            if not has_open and not has_close:
                self.tw_open_minute = DEFAULT_TW_OPEN_MINUTES
                self.tw_close_minute = DEFAULT_TW_CLOSE_MINUTES
                has_open = has_close = True
            if not (has_open and has_close):
                raise ValueError(
                    "time-constrained node requires both tw_open_minute and "
                    "tw_close_minute (or neither, to accept the default window)"
                )
        elif has_open or has_close:
            #window bounds supplied without the flag -> promote to constrained
            self.is_time_constrained = True
            if not (has_open and has_close):
                raise ValueError(
                    "a partial time window was supplied; provide both bounds"
                )

        if (
            self.tw_open_minute is not None
            and self.tw_close_minute is not None
            and self.tw_close_minute <= self.tw_open_minute
        ):
            raise ValueError(
                "tw_close_minute must be strictly after tw_open_minute "
                f"(got open={self.tw_open_minute}, close={self.tw_close_minute})"
            )
        return self

    @property
    def time_window(self) -> Optional[TimeWindow]:
        if self.tw_open_minute is not None and self.tw_close_minute is not None:
            return TimeWindow(
                open_minute=self.tw_open_minute, close_minute=self.tw_close_minute
            )
        return None


class DeliveryNodeCreate(DeliveryNodeBase):
    pass


class DeliveryNodeRead(DeliveryNodeBase):

    model_config = ConfigDict(from_attributes=True)

    id: int

#distance et time matrix schemas


class GeoLocation(BaseModel):

    key: str = Field(min_length=1, max_length=48)
    latitude: Latitude
    longitude: Longitude


class MatrixBuildRequest(BaseModel):

    locations: list[GeoLocation] = Field(min_length=2)
    circuity_factor: PosFloat = DEFAULT_CIRCUITY_FACTOR
    free_flow_kmh: PosFloat = DEFAULT_FREE_FLOW_KMH
    use_osrm: bool = False
    osrm_base_url: Optional[str] = None
    osrm_profile: str = "driving"

    @model_validator(mode="after")
    def _osrm_requires_url(self) -> "MatrixBuildRequest":
        if self.use_osrm and not self.osrm_base_url:
            raise ValueError("osrm_base_url is required when use_osrm is True")
        keys = [loc.key for loc in self.locations]
        if len(set(keys)) != len(keys):
            raise ValueError("location keys must be unique")
        return self


class ArcTravelQuery(BaseModel):

    origin_key: str
    destination_key: str
    departure_minute: NonNegFloat


class ArcTravelResult(BaseModel):

    origin_key: str
    destination_key: str
    departure_minute: float
    arrival_minute: float
    distance_km: float
    free_flow_minutes: float
    travel_minutes: float
    crosses_peak: bool
    peak_inflation_ratio: float = Field(
        description="effective travel time / free-flow time (>= 1.0)"
    )


class MatrixSummary(BaseModel):

    size: int
    keys: list[str]
    total_arcs: int
    provider: str


__all__ = [
    "TimeWindow",
    "VehicleBase",
    "VehicleCreate",
    "VehicleRead",
    "DepotBase",
    "DepotCreate",
    "DepotRead",
    "DeliveryNodeBase",
    "DeliveryNodeCreate",
    "DeliveryNodeRead",
    "GeoLocation",
    "MatrixBuildRequest",
    "ArcTravelQuery",
    "ArcTravelResult",
    "MatrixSummary",
]
