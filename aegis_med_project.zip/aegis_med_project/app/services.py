from __future__ import annotations

import dataclasses
import datetime as dt
import os
from collections.abc import Mapping, Sequence
from typing import Optional

from sqlalchemy import select, update
from sqlalchemy.orm import Session

from .alns_engine import EngineConfig, ProblemInstance, Solution
from .alns_search import alns_optimize
from .database import session_scope
from .jobs_models import JobStatus, OptimizationJob, RouteAssignment
from .models import DeliveryNode, Depot, Vehicle
from .spatial import (
    DistanceProvider,
    OSRMDistanceProvider,
    SyntheticDistanceProvider,
    build_time_dependent_matrix,
    load_matrix,
    locations_from_entities,
    persist_matrix,
)


class EntityNotFoundError(Exception):
    pass


def _default_provider() -> DistanceProvider:
    # Live OSRM when AEGIS_OSRM_URL is configured, otherwise the synthetic matrix.
    url = os.getenv("AEGIS_OSRM_URL")
    if url:
        return OSRMDistanceProvider(
            base_url=url, profile=os.getenv("AEGIS_OSRM_PROFILE", "driving")
        )
    return SyntheticDistanceProvider()


#: Error stamped on jobs found stranded by a previous aborted process.
ORPHAN_ERROR_MESSAGE = (
    "Job aborted due to unexpected worker process termination during server restart."
)


def _utcnow() -> dt.datetime:
    return dt.datetime.now(dt.timezone.utc)


# Engine configuration


def build_engine_config(
    overrides: Optional[Mapping[str, object]] = None,
) -> EngineConfig:
    base = EngineConfig()
    if not overrides:
        return base
    valid = {f.name for f in dataclasses.fields(EngineConfig)}
    filtered = {k: v for k, v in overrides.items() if k in valid and v is not None}
    if not filtered:
        return base
    return dataclasses.replace(base, **filtered)

# Data bridge: ORM entities -> ProblemInstance


def build_problem_instance(
    session: Session,
    depot_id: int,
    node_ids: Sequence[int],
    vehicle_ids: Sequence[int],
    *,
    config: Optional[EngineConfig] = None,
    provider: Optional[DistanceProvider] = None,
    use_cache: bool = True,
) -> ProblemInstance:
    depot = session.get(Depot, depot_id)
    if depot is None:
        raise EntityNotFoundError(f"depot {depot_id} not found")

    nodes = list(
        session.scalars(select(DeliveryNode).where(DeliveryNode.id.in_(node_ids)))
    )
    node_by_id = {n.id: n for n in nodes}
    missing_nodes = [nid for nid in node_ids if nid not in node_by_id]
    if missing_nodes:
        raise EntityNotFoundError(f"delivery nodes not found: {missing_nodes}")

    vehicles = list(
        session.scalars(select(Vehicle).where(Vehicle.id.in_(vehicle_ids)))
    )
    vehicle_by_id = {v.id: v for v in vehicles}
    missing_vehicles = [vid for vid in vehicle_ids if vid not in vehicle_by_id]
    if missing_vehicles:
        raise EntityNotFoundError(f"vehicles not found: {missing_vehicles}")

    ordered_nodes = [node_by_id[nid] for nid in node_ids]
    ordered_vehicles = [vehicle_by_id[vid] for vid in vehicle_ids]

    locations = locations_from_entities([depot, *ordered_nodes])
    keys = [loc.key for loc in locations]

    matrix = None
    if use_cache:
        try:
            matrix = load_matrix(session, keys)
        except Exception:
            # Cache miss / incomplete / unavailable -> rebuild below.
            matrix = None
    if matrix is None:
        matrix = build_time_dependent_matrix(
            locations, provider or _default_provider()
        )
        try:
            persist_matrix(session, matrix)
        except Exception:
            # The cache is an optimization not a correctness requirement
            pass

    return ProblemInstance.from_entities(
        depot=depot,
        nodes=ordered_nodes,
        vehicles=ordered_vehicles,
        matrix=matrix,
        config=config or EngineConfig(),
    )


# Result persistence


def persist_solution(
    session: Session, job: OptimizationJob, solution: Solution
) -> OptimizationJob:
    #Clear any prior assignments (idempotent reruns)
    job.route_assignments.clear()

    sequence = 0
    for route, evaluation in zip(solution.routes, solution.evaluations):
        if route.is_empty:
            continue
        job.route_assignments.append(
            RouteAssignment(
                sequence_index=sequence,
                vehicle_id=route.vehicle.id,
                vehicle_label=route.vehicle.label,
                visits=list(route.visits),
                load_kg=float(evaluation.load_kg),
                distance_km=float(evaluation.distance_km),
                shift_minutes=float(evaluation.shift_duration),
                max_seal_minutes=float(evaluation.max_seal_time),
                time_value=float(evaluation.time_value),
                distance_cost=float(evaluation.distance_cost),
                reliability=float(evaluation.reliability),
                feasible=bool(evaluation.feasible),
            )
        )
        sequence += 1

    job.objective = dataclasses.asdict(solution.objective)
    job.total_cost = float(solution.objective.total)
    job.feasible = bool(solution.feasible)
    job.unassigned = list(solution.unassigned)
    job.status = JobStatus.COMPLETED
    job.finished_at = _utcnow()
    session.add(job)
    return job


#background worker


def run_optimization_job(
    job_id: str,
    depot_id: int,
    node_ids: Sequence[int],
    vehicle_ids: Sequence[int],
    config_overrides: Optional[Mapping[str, object]] = None,
) -> None:
    config = build_engine_config(config_overrides)
    try:
        #1)Mark RUNNING
        with session_scope() as session:
            job = session.get(OptimizationJob, job_id)
            if job is None:
                return
            job.status = JobStatus.RUNNING
            job.started_at = _utcnow()

        #2.oad data+ matrix then release the connection
        with session_scope() as session:
            instance = build_problem_instance(
                session, depot_id, list(node_ids), list(vehicle_ids), config=config
            )

        #3 Heavy compute with no DB connection held 
        best = alns_optimize(instance)

        #4)Persist result + mark COMPLETED 
        with session_scope() as session:
            job = session.get(OptimizationJob, job_id)
            if job is None:
                return
            persist_solution(session, job, best)

    except Exception as exc:  # noqa: BLE001rec ord any failure on the job
        with session_scope() as session:
            job = session.get(OptimizationJob, job_id)
            if job is not None:
                job.status = JobStatus.FAILED
                job.error = f"{type(exc).__name__}: {exc}"
                job.finished_at = _utcnow()


def fail_job_if_unfinished(job_id: str, error: str) -> bool:
    with session_scope() as session:
        job = session.get(OptimizationJob, job_id)
        if job is None or job.status not in (JobStatus.PENDING, JobStatus.RUNNING):
            return False
        job.status = JobStatus.FAILED
        job.error = error
        job.finished_at = _utcnow()
        return True


def recover_orphaned_jobs() -> int:
    stmt = (
        update(OptimizationJob)
        .where(OptimizationJob.status.in_([JobStatus.RUNNING, JobStatus.PENDING]))
        .values(
            status=JobStatus.FAILED,
            finished_at=_utcnow(),
            error=ORPHAN_ERROR_MESSAGE,
        )
        .execution_options(synchronize_session=False)
    )
    with session_scope() as session:
        result = session.execute(stmt)
        return int(result.rowcount or 0)


def warm_matrix_cache(
    depot_id: int,
    node_ids: Sequence[int],
    vehicle_ids: Sequence[int],
) -> int:
    with session_scope() as session:
        instance = build_problem_instance(
            session,
            depot_id,
            list(node_ids),
            list(vehicle_ids),
            use_cache=False,
        )
        return instance.matrix.size


__all__ = [
    "EntityNotFoundError",
    "ORPHAN_ERROR_MESSAGE",
    "build_engine_config",
    "build_problem_instance",
    "persist_solution",
    "run_optimization_job",
    "fail_job_if_unfinished",
    "recover_orphaned_jobs",
    "warm_matrix_cache",
]
