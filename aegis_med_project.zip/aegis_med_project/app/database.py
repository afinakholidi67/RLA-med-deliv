from __future__ import annotations

import os
from collections.abc import Iterator
from contextlib import contextmanager

from sqlalchemy import create_engine
from sqlalchemy.engine import Engine
from sqlalchemy.orm import Session, sessionmaker

#Connection string. Defaults to a local PostGIS-enabled PostgreSQL instance
#override with the AEGIS_DATABASE_URL environment variable 
DATABASE_URL: str = os.getenv(
    "AEGIS_DATABASE_URL",
    "postgresql+psycopg://aegis:aegis@localhost:5432/aegis_med",
)

#SQLite needs check_same_thread disabled so background worker threads may
#reuse the engine PostgreSQL ignores unknown connect args, so i gate it
_connect_args: dict[str, object] = (
    {"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {}
)

engine: Engine = create_engine(
    DATABASE_URL,
    pool_pre_ping=True,
    pool_recycle=1800,
    future=True,
    connect_args=_connect_args,
)

SessionLocal = sessionmaker(
    bind=engine,
    class_=Session,
    autoflush=False,
    autocommit=False,
    expire_on_commit=False,
)


def get_session() -> Iterator[Session]:
    session = SessionLocal()
    try:
        yield session
    finally:
        session.close()


@contextmanager
def session_scope() -> Iterator[Session]:
    session = SessionLocal()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()


def create_all() -> None:
    from . import jobs_models, models  # noqa: F401  (registers tables)

    models.Base.metadata.create_all(bind=engine)


def dispose_engine() -> None:
    engine.dispose()


def reset_pool_after_fork() -> None:
    # drop the inherited pool without closing the parent's sockets
    engine.dispose(close=False)


__all__ = [
    "DATABASE_URL",
    "engine",
    "SessionLocal",
    "get_session",
    "session_scope",
    "create_all",
    "dispose_engine",
    "reset_pool_after_fork",
]
